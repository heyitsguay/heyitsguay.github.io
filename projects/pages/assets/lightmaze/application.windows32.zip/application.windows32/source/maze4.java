import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class maze4 extends PApplet {

// maze2 - Matthew Guay, 01/04/2015
// An iteration on 'maze', hopefully a refinement!
// Procedurally-generated mazes with some other cool things happening.

// TODO:
//
// - Create a Skeleton
// - Add Player-specific sprite animation info to the Player class
// - Fix entity sprite animation to handle more than just the Player sprite sheet.
// - Make tile color get more variable towards the center of the maze
//
// x Add "Click to make a light pulse". DONE 8/7/20
// x Add light pulse charge to HUD. DONE 8/7/20
// x Set player and lightList lighting dynamics to match maze1. DONE 8/6/20
//   x Set player light addition to match maze1. DONE 8/6/20
//   x Set lightlist updates to match maze1. DONE 8/6/20
//   x Add Tile desat. DONE 8/5/20
// x Add player light "breathing" effect. DONE 8/6/20
// x Do maze1-style tile color setup and rendering instead of images. DONE 8/7/20
// x Disable room coloration (or better yet, have it do something cool like changing the light color). DONE 8/7/20
// x Add maze1-style items. DONE 8/8/20
// x Remove torches. DONE 8/6/20
// x Use maze1-style setup plan. DONE 8/6/20
//   x Finish MazePlan2. DONE 8/6/20
// 
// x Finish writing Room's constructor (add Rectangles + their Tiles). DONE 2/11/15
// x Write Item code: interface instead of class? DONE 2/15/15
// x Finish Entity code. DONE 2/13/15
// x Finish Player code. DONE 2/17/15
// x Revert colors back to float triplets. DONE 2/14/15
// x Finish LightList code. DONE 2/15/15
// x Finish MazePlan1. DONE 2/15/15
// x Add HUD class. DONE 2/17/15
// x Add Tile initialization after MazePlan1 runs. DONE 2/17/15
// x Get maze2 running! DONE 2/22/15
// - Entity collision.
// x Add key press functions. DONE 2/17/15
// x Add to Entity update code to include Entities in Tile and Chunk entityLists. DONE 2/25/15
// x Fix Entity-Tile collisions. DONE 2/22/15
// x Player textures/animations. DONE 2/25/15

// Some useful constants.
final float ISQRT2 = 1 / sqrt(2);
final float SQRT2 = sqrt(2);

int TILE_SIZE = 64; // Size of each Tile in pixels.
int CHUNK_SIZE = 32; // 32x32 Tiles in a Chunk.
int CHUNKSX = 16;
int CHUNKSY = 16;

int tilesX = CHUNKSX * CHUNK_SIZE;
int tilesY = CHUNKSY * CHUNK_SIZE;
int chunkPix = CHUNK_SIZE * TILE_SIZE;
// Size of the World, in pixels.
int pixWidth = CHUNKSX * CHUNK_SIZE * TILE_SIZE;
int pixHeight = CHUNKSY * CHUNK_SIZE * TILE_SIZE;

// Maximum number of Tiles potentially on the screen at once.
int tilesOnScreenX;// = (int)(width / TILE_SIZE) + 2;
int tilesOnScreenY;// = (int)(height / TILE_SIZE) + 2;

// Maximum number of Chunks potentially on the screen at once.
int chunkDrawRadiusX;
int chunkDrawRadiusY;

// Screen position within the maze is calculated relative to the
// upper-left hand corner of the window. maxScreenX, maxScreenY
// give the coordinates for the largest value this anchor point 
// can take.
int maxScreenX = pixWidth - width;
int maxScreenY = pixHeight - height;

// (x,y) World coordinates of the top-left corner of the window.
float screenX = 0.f;
float screenY = 0.f;

float baseItemProbability = 0.008f;

// Display additional information when true
boolean debugMode = false;

// Tile array containing all the Tiles in the game.
Tile[][] tiles;

// Chunk array containing all the Chunks in the game.
Chunk[][] chunks;

// A world object that contains functions for altering Arrays tiles and chunks.
World world; 

// The person playing the game.
Player player;

// List of all Tiles getting active lighting updates in a given frame.
LightList lightList;

// HUD class
HUD hud;

// Win time
float winTime;
float waitTime = 5000;

// Start in tileArray[xtstart][ytstart], win at tileArray[xtwin][ytwin]
float xwstart, ywstart;
int xtstart, ytstart;
int xtwin, ytwin;
float maxDistance;

float t = 0; // Current 'time', incremented by dt every frame
float dt = 1.f/30.f; // Used as an increment amount for physics updates. 

// keyList[key]==true if key is currently pressed, where key is a Unicode character between 0 and numKeys.
boolean[] keyList;
boolean[] keyPressedList;
int numKeys = 256;

// Image assets
PImage tileSheet1;
PImage playerSheet;

// Controls rates of change for tile hue and its derivative
float dhRate = 0.03f;
float d2hRate = 0.08f;

// Base tile hue far away from the win tile
float baseHue;

// Maze generation RNG seed
int seed;// 385823;

public void setup()
{
  seed = PApplet.parseInt(random(pow(2,32)));
  println("Using seed " + str(seed));
  //size(1366, 768, P2D);
  
  background(0);
  colorMode(HSB, 1.0f);
  
  
  hint(DISABLE_TEXTURE_MIPMAPS);
  ((PGraphicsOpenGL)g).textureSampling(2);
  
  // Load image assets.
  tileSheet1 = loadImage("sprites/tileSheet1.png");
  playerSheet = loadImage("sprites/player.png", "png");
  
  
  tilesOnScreenX = (int)(width / TILE_SIZE) + 2;
  tilesOnScreenY = (int)(height / TILE_SIZE) + 2;
  
  chunkDrawRadiusX = PApplet.parseInt(width / chunkPix) + 1;
  chunkDrawRadiusY = PApplet.parseInt(height / chunkPix) + 1;
  
  lightList = new LightList();
  MazePlan2 mazePlan = new MazePlan2();
  //MazePlanDemo mazePlan = new MazePlanDemo();
  keyList = new boolean[numKeys];
  keyPressedList = new boolean[numKeys];
  hud = new HUD();
  
  world = new World(mazePlan, seed);
  
  player = new Player(xwstart, ywstart);
}

public void draw()
{
  //println(frameRate);
  //println(player.animationState);

  keyCheck();
  
  switch(world.state)
  {
    case W_PAUSE: // Game is paused, gray the screen.
      fill(0, 0, 1, 0.1f);
      rect(0, 0, width, height);
      break;
      
    case W_PLAY: // Normal game play.
    
      clear();
      
      // Update world
      world.update();
      
      world.display();
      
      // Update and draw the HUD
      hud.update();
      hud.display();
      
      break;
    
    case W_WIN: // player has found the winning Tile.
    
      loadPixels();
      for(int i = 0; i < width*height; i++) {
        int c = pixels[i];
        float ch = hue(c);
        float cb = brightness(c);
        pixels[i] = color(ch, 1, cb * 0.975f);
      }
      updatePixels();
      
      textSize(48);
      fill(0, 0, 1);
      
      text("You Win!!", round(0.5f * width - 180), 0.5f * height - 24);
    
      if (millis() - winTime >= waitTime) {
        exit();
      }
      
      break;
  }
}
// uses the following global variables defined in maze2
// - int TILE_SIZE
// - int CHUNK_SIZE
// - int chunkPix
// - Chunk[][] chunks
// - Tile[][] tiles

class Chunk
{
  // (x,y) Chunk coordinates 
  int xc;
  int yc;
  
  // (x,y) World coordinates of the top-left corner of this Chunk. (0,0) is the top-left pixel of the maze.
  int xw;
  int yw;
  
  // Tiles with Tile coordinates (xt0,yt0) to (xt1,yt1) reside in this Chunk.
  int xt0, xt1;
  int yt0, yt1;
  
  // List of all Entities whose intersection with this Chunk is nonempty.
  ArrayList<Entity> entityList;
  
  // List of all Items located on a Tile within this Chunk.
  ArrayList<Item> itemList;
  
  //////////////////////////////////////////////////////////////////////////////////
  Chunk(int xc_, int yc_)
  {
    xc = xc_;
    yc = yc_;
    
    xw = xc * chunkPix;
    yw = yc * chunkPix;
    
    xt0 = xc * CHUNK_SIZE;
    yt0 = yc * CHUNK_SIZE;
    
    xt1 = xt0 + CHUNK_SIZE - 1;
    yt1 = yt0 + CHUNK_SIZE - 1;
    
    entityList = new ArrayList<Entity>();
    itemList = new ArrayList<Item>(); 
  }
  
  ///////////////////////////////////////////////////////////////////////////////////
  public void updateEntities()
  {
    if(entityList.size() > 0)
    {
      for(int i = entityList.size() - 1; i >= 0; i--)
      {
        entityList.get(i).update();
      }
    }
  }
  
  public void drawEntities()
  {
    if(entityList.size() > 0)
    {
      for(int i = entityList.size() - 1; i >= 0; i--)
      {
        entityList.get(i).display();
      }
    }
  }
  
}
  
  
// *******************************************************
// *******************************************************
class Collision
{
  Entity entity1;
  Entity entity2;
  
  /////////////////////////////////////////////////////////////////////////////////////////////
  Collision(Entity entity1_, Entity entity2_)
  {
    entity1 = entity1_;
    entity2 = entity2_;
  }
  
  /////////////////////////////////////////////////////////////////////////////////////////////
  public void Update1()
  {
  }
  
  //////////////////////////////////////////////////////////////////////////////////////////////
  public void update2()
  {
  }
}

// *********************************************************
// *********************************************************
class CollisionPlayer extends Collision
{
  // Collision initiated by the player
  
  ///////////////////////////////////////////////////////////////////////////////////////////////
  CollisionPlayer(Entity entity2_)
  {
    super(player, entity2_);
  }
}
// Mnemonic variable names for the 4 direction values used by Creators.
final char D_UP = 0;
final char D_RIGHT = 1;
final char D_DOWN = 2;
final char D_LEFT = 3;

class Creator
{
  // Creates the traversable portions of the maze.
  
  // Tile coordinates of the Creator.
  int xt, yt;
  
  // World coordinates of the Creator.
  int xw, yw;
  
  // Putative new Tile coordinates used in calculating movement.
  int xtnew, ytnew;
  
  // Angle in [0, 2*PI) relative to the positive x axis. Creator trajectories will be biased
  // towards this direction.
  float directionBias;
  
  // Strength of that trajectory bias, takes values in [0,+Infinity)
  float directionBiasStrength;
  
  // The arbitrary-angle directionBias gets transformed into bias amounts in the four cardinal
  // directions. 
  float biasUp, biasRight, biasDown, biasLeft;
  
  // Can be anything in (-Infinity, +Infinity). Large positive numbers drive the Creator
  // towards the winning Tile. Large negative numbers drive the Creator away from the
  // winning Tile.
  float winBias;
  
  // Can be anything in (-Infinity, +Infinity). Large positive numbers drive the Creator
  // towards the start Tile. Large negative numbers drive the Creator away from the
  // start Tile.
  float startBias;
  
  // Corridor lengths are chosen randomly from a normal distribution with this mean.
  float lengthMean; 
  
  // Corridor lengths are chosen randomly from a normal distribution with this standard deviation.
  float lengthSD; 
  
  // Corridor width generated by the Creator.
  int corridorWidth;
  
  // Lower bound on Corridor length.
  int lengthMin; 
  
  // Probability of avoiding connecting to an existing hallway. When 1, totally self-avoiding.
  float avoidProb; 
  
  // The current heading of the Creator: D_UP, D_RIGHT, D_DOWN, D_LEFT for mnemonic ease
  char direction;
  
  // Number of moves remaining in the current direction before picking a new one.
  int movesLeft;
  
  // Number of updates the Creator performs before being deleted.
  int lifeTime;
  
  // Number of updates presently remaining.
  int lifeRemaining;
  
  Creator(
    int xt_, 
    int yt_, 
    float directionBias_, 
    float directionBiasStrength_, 
    float winBias_, 
    float startBias_,
    float lengthMean_, 
    float lengthSD_, 
    int lengthMin_, 
    int corridorWidth_, 
    float avoidProb_, 
    char direction_, 
    int lifeTime_
    )
  {
    xt = xt_; 
    yt = yt_;
    xtnew = xt;
    ytnew = yt;
    xw = xt * TILE_SIZE;
    yw = yt * TILE_SIZE;
    
    directionBias = directionBias_;
    directionBiasStrength = directionBiasStrength_;
    
    // Decompose the directionBias into biases in the four cardinal directions.
    if(directionBias >= 0 && directionBias < PI / 2)
    {
      // First quadrant angle.
      biasUp = sin(directionBias) * directionBiasStrength;
      biasRight = cos(directionBias) * directionBiasStrength;
      biasDown = 0;
      biasLeft = 0;
    }
    else if(directionBias >= PI / 2 && directionBias < PI)
    {
      // Second quadrant angle.
      biasUp = sin(directionBias) * directionBiasStrength;
      biasRight = 0;
      biasDown = 0;
      biasLeft = - cos(directionBias) * directionBiasStrength;
    }
    else if(directionBias >= PI && directionBias < 3 * PI / 2)
    {
      // Third quadrant angle.
      biasUp = 0;
      biasRight = 0;
      biasDown = - sin(directionBias) * directionBiasStrength;
      biasLeft = - cos(directionBias) * directionBiasStrength;
    }
    else if(directionBias >= 3 * PI / 2 && directionBias < 2 * PI)
    {
      // Fourth quadrant angle.
      biasUp = 0;
      biasRight = cos(directionBias) * directionBiasStrength;
      biasDown = - sin(directionBias) * directionBiasStrength;
      biasLeft = 0;
    }
    
    winBias = winBias_;
    startBias = startBias_;
    
    lengthMean = lengthMean_;
    lengthSD = lengthSD_;
    lengthMin = lengthMin_;
    corridorWidth = corridorWidth_;
    
    avoidProb = avoidProb_;
    
    direction = direction_;
    
    lifeTime = lifeTime_;
    lifeRemaining = lifeTime;
    
    movesLeft = rollMoves();
  }
  
  /////////////////////////////////////////////////////////////////////////////////////
  public void move()
  {
    // Run changeTiles, convert wall Tiles to path Tiles.
    changeTiles(T_WALL, T_PATH);
    
    lifeRemaining -= 1;
    
    if(movesLeft == 0)
    {
      // Out of moves, choose new direction. Can be the same as the old direction.
      update(false);
    }
    
    switch(direction)
    {
      case D_UP: // Move up
        xtnew = xt;
        ytnew = yt - 1;
        break;
      
      case D_RIGHT: // Move right
        xtnew = xt + 1;
        ytnew = yt;
        break;
        
      case D_DOWN: // Move down
        xtnew = xt;
        ytnew = yt + 1;
        break;
        
      case D_LEFT: // Move left
        xtnew = xt - 1;
        ytnew = yt;
        break;
    }
    
    if(xtnew == 0 || xtnew > tilesX-2 || ytnew == 0 || ytnew > tilesY-2)
    {
      // Check to see whether the new move puts us on the tileArray boundary, avoid if so.
      
      // Update currentDirection, new value can't be the same as the previous.
      update(true); 
      return;
    }
    
    if(tiles[xtnew][ytnew].neighborList.size() > 1)
    {
      // If true, new Tile borders another existing path Tile besides the one at tiles[xt][yt].
      if(random(1.0f) < avoidProb)
      {
        // Avoid this new Tile.
        update(true);
        return;
      }
    }
    
    // If move() hasn't returned by now, move the Creator to the new location.
    xt = xtnew;
    yt = ytnew;
    movesLeft -= 1;
    
    
  }
  
  /////////////////////////////////////////////////////////////////////////////////////
  public void update(boolean avoidPrevDirection)
  {
    // Create a new probability distribution over the possible motion directions, and then
    // sample from it.
    
    int prevDirection = direction;
    
    // Ultimately this will contain a probability distribution over the possible new directions, but we won't
    // normalize it until the last step in its calculation.
    float[] newDirectionP = {1.0f + biasUp, 1.0f + biasRight, 1.0f + biasDown, 1.0f + biasLeft};
    
    // Add in winning Tile bias
    if(xtwin > xt) 
    {
      // Winning Tile is to the right
      newDirectionP[D_RIGHT] = max(newDirectionP[D_RIGHT] + winBias, 0);
      newDirectionP[D_LEFT] = max(newDirectionP[D_LEFT] - winBias, 0);
    }
    else if(xtwin < xt) 
    {
      // Winning Tile is to the left
      newDirectionP[D_RIGHT] = max(newDirectionP[D_RIGHT] - winBias, 0);
      newDirectionP[D_LEFT] = max(newDirectionP[D_LEFT] + winBias, 0);
    }
    
    if(ytwin < yt)
    {
      // Winning Tile is up.
      newDirectionP[D_UP] = max(newDirectionP[D_UP] + winBias, 0);
      newDirectionP[D_DOWN] = max(newDirectionP[D_DOWN] - winBias, 0);
    }
    else if(ytwin > yt)
    {
      // Winning Tile is down.
      newDirectionP[D_UP] = max(newDirectionP[D_UP] - winBias, 0);
      newDirectionP[D_DOWN] = max(newDirectionP[D_DOWN] + winBias, 0);
    }
    
    // Add in start Tile bias
    if(xtstart > xt) 
    {
      // Start Tile is to the right
      newDirectionP[D_RIGHT] = max(newDirectionP[D_RIGHT] + startBias, 0);
      newDirectionP[D_LEFT] = max(newDirectionP[D_LEFT] - startBias, 0);
    }
    else if(xtstart < xt) 
    {
      // Start Tile is to the left
      newDirectionP[D_RIGHT] = max(newDirectionP[D_RIGHT] - startBias, 0);
      newDirectionP[D_LEFT] = max(newDirectionP[D_LEFT] + startBias, 0);
    }
    
    if(ytstart < yt)
    {
      // Start Tile is up.
      newDirectionP[D_UP] = max(newDirectionP[D_UP] + startBias, 0);
      newDirectionP[D_DOWN] = max(newDirectionP[D_DOWN] - startBias, 0);
    }
    else if(ytstart > yt)
    {
      // Start Tile is down.
      newDirectionP[D_UP] = max(newDirectionP[D_UP] - startBias, 0);
      newDirectionP[D_DOWN] = max(newDirectionP[D_DOWN] + startBias, 0);
    }
    
    if(avoidPrevDirection)
    {
      // Set the newDirectionP[prevDirection] to 0, add a small chance of going the
      // other way to prevent stagnation.
      newDirectionP[prevDirection] = 0;
      newDirectionP[(prevDirection + 2) % 4] += 0.1f;
    }
    
    // Normalize newDirectionPs to create a probability vector.
    float pSum = newDirectionP[0] + newDirectionP[1] + newDirectionP[2] + newDirectionP[3];
    newDirectionP[0] /= pSum;
    newDirectionP[1] /= pSum;
    newDirectionP[2] /= pSum;
    newDirectionP[3] /= pSum;
    
    // Choose the new direction.
    float directionDecider = random(1.0f);
    
    if(directionDecider < newDirectionP[0])
    {
      direction = D_UP;
    }
    else if(directionDecider < newDirectionP[0] + newDirectionP[1])
    {
      direction = D_RIGHT;
    }
    else if(directionDecider < newDirectionP[0] + newDirectionP[1] + newDirectionP[2])
    {
      direction = D_DOWN;
    }
    else
    {
      direction = D_LEFT;
    }
    
    // Reset movesLeft.
    movesLeft = rollMoves();
    
    // Make the Creator more self-avoiding
    avoidProb += 0.4f * (1.0f - PApplet.parseFloat(lifeRemaining)/PApplet.parseFloat(lifeTime)) * (1 - avoidProb);
    
  }
  
  /////////////////////////////////////////////////////////////////////////////////////
  public void changeTiles(int type0, int type1)
  {
    // Changes all Tiles  of type type0 to type type1, within radius widthRadius of
    // the Creator's location.
    
    int wmin, wmax;
    Tile theTile;
    
    // Left (min) and right (max) boundary Tile coordinates of the current
    // hallway's width.
    wmin = - (corridorWidth - 1) / 2;
    wmax =  PApplet.parseInt(ceil(PApplet.parseFloat(corridorWidth - 1) / 2.f));
    
    // size is perpendicular to the direction of the Creator.
    switch(direction)
    {
      case D_UP:
        // Make sure the changed Tiles stay in the Tile array (plus a 1-Tile border).
        wmin = max(1, xt + wmin) - xt;
        wmax = min(pixWidth-2, xt + wmax) - xt;
        
        for(int i = wmin; i <= wmax; i++)
        {
          theTile = tiles[xt+i][yt];
          
          if(theTile.type == type0) // If type0, change to type1.
          {
            theTile.setType(type1);
          }
        }
        break;
      
      case D_RIGHT:
        // Make sure the changed Tiles stay in the Tile array (plus a 1-Tile border).
        wmin = max(1, yt + wmin) - yt;
        wmax = min(pixHeight-2, yt + wmax) - yt;
        
        for(int i = wmin; i <= wmax; i++)
        {
          theTile = tiles[xt][yt+i];
          
          if(theTile.type == type0)
          {
            theTile.setType(type1);
          }
        }
        break;
        
      case D_DOWN:
        // Make sure the changed Tiles stay in the Tile array (plus a 1-Tile border).
        wmin = xt - min(pixWidth-2, xt - wmin);
        wmax = xt - max(1, xt - wmax);
        
        for(int i = wmin; i <= wmax; i++)
        {
          theTile = tiles[xt-i][yt];
          
          if(theTile.type == type0)
          {
            theTile.setType(type1);
          }
        }
        break;
        
      case D_LEFT:
        // Make sure the changed Tiles stay in the Tile array (plus a 1-Tile border).
        wmin = yt - min(pixHeight-2, yt - wmin);
        wmax = yt - max(1, yt - wmax);
        
        for(int i = wmin; i <= wmax; i++)
        {
          theTile = tiles[xt][yt-i];
          
          if(theTile.type == type0)
          {
            theTile.setType(type1);
          }
        }
        break;
    }
    

  }
  
  /////////////////////////////////////////////////////////////////////////////////////
  public int rollMoves()
  {
    // Calculate a random number indicating how far a Creator will
    // move in its present direction before changing course.
    return max(PApplet.parseInt(lengthSD * randomGaussian() + lengthMean), lengthMin);  
  }
}
  
// **************************************
// **************************************
class Torch extends Entity
{
  int ID = 0;
  
  // How much light the Torch creates.
  float glow;
  
  // Frequency (in Hz) of the Torch's light oscillation.
  float freq;
  
  //////////////////////////////////////////////////////////////////////////////////////////
  Torch(float xcenter_, float ycenter_, float glow_)
  {
    super(8, 24, 0, 0.1f, xcenter_ - 4, ycenter_ - 12, 0, 0, 10, 0, 0, 10, 10, 0.1362f, 0.95f, 1, true, true);
    freq = 1/random(5, 15);
    glow = glow_;
  }
  
  //////////////////////////////////////////////////////////////////////////////////////////
  public void update()
  {
    // Light up the Tile that player is centered on
    tiles[xtcenter][ytcenter].c_bactiveNew += glow  * (1 + 0.3f * sin(2 * PI * freq * t));
    lightList.addTile(tiles[xtcenter][ytcenter]);
  }
}

// **************************************
// **************************************
//class Monster extends Entity
//{
//  float health;
//  float maxHealth;
//  
//  float energy;
//  float maxEnergy;
//  float energyCost; // Energy diminishes exponentially with this rate parameter.
//  float energyRechargeRate; // Governs how quickly energy recharges.
//  
//  float glow;
//  
//  // Player movement speed.
//  float moveSpeed;
//  
//  float alignment = A_HOSTILE;
//}
// Mnemonic variable names for Entity orientations
final char O_U = 0;
final char O_UR = 1;
final char O_R = 2;
final char O_DR = 3;
final char O_D = 4;
final char O_DL = 5;
final char O_L = 6;
final char O_UL = 7;

// Mnemonic variable names for Entity alignments
final char A_FRIEND = 0;
final char A_NEUTRAL = 1;
final char A_HOSTILE = 2;

class Entity
{
  // width and height of the Entity's image box.
  float w;
  float h;
  
  // Entity mass.
  float mass;
  
  // Position x and y (World) coordinates (upper-left hand corner of the image box).
  float x;
  float y;
  
  // x and y Tile coordinates of the upper-left corner of Entity's image box.
  int xt;
  int yt;
  
  // x and y Chunk coordinates of the upper-left corner of the Entity's image box.
  int xc;
  int yc;
  
  // Center World coordinates.
  float xcenter;
  float ycenter;
  
  // Center Tile coordinates.
  int xtcenter;
  int ytcenter;
  
  // Velocity x and y coordinates.
  float vx;
  float vy;
  float vmax; // maximum magnitude of vx or vy (so max speed is sqrt(2)*vmax).
  
  // Acceleration x and y coordinates.
  float ax;
  float ay;
  float amax;
  
  // Entity's contribution to friction.
  float friction;
  
  // Allow the bounding box to be (slightly) smaller than the image box.
  float boundingBoxOffset; 
  
  // Last side of the Entity that resolved an Entity-Tile collision. Initialize to whatever.
  char lastResolutionSide = D_UP;
  
  float xbb, ybb; // Entity position (x,y) World coordinates, offset by boundingBoxOffset.
  float wbb, hbb; // Entity bounding box width and height.
  
  float xbbLast, ybbLast; // Entity bounding box (x,y) World coordinates in the previous frame. 
  int xtLast, ytLast; // Tile coordinates of bounding box top-left corner in the previous frame.
  int xcLast, ycLast; // Chunk coordinates of bounding box top-left corner in the previous frame.

  // True if this Entity has collided with something during this frame.
  boolean justCollided = false;
  
  // HSB triplet of Entity color values, range [0,1].
  float c_h, c_s, c_b;

  // If ghost, this Entity passes through other Entities and blocked Tiles (no collisions).
  boolean ghost;  
  
  // If fixed, never update position
  boolean fixed;
  
  // If dead, eventually add a routine to handle the removal of the entity.
  boolean dead = false;
  
  // Orientation, determined by difference between present and last position.
  char orientation = O_D;
  
  // Tracks which frame of the Entity's animation is being displayed.
  float animationState = 0;
  
  // How many frames to stay in each state.
  int framesPerState = 8;
  
  // Entity alignment: Friendly (A_FRIEND), Neutral (A_NEUTRAL), Hostile (A_HOSTILE).
  char alignment = A_NEUTRAL;
  
  ////////////////////////////////////////////////////////////////////////////////
  Entity(
    float w_,
    float h_,
    float boundingBoxOffset_,
    float mass_,
    float x_,
    float y_,
    float vx_,
    float vy_,
    float vmax_,
    float ax_,
    float ay_,
    float amax_,
    float friction_,
    float c_h_,
    float c_s_,
    float c_b_,
    boolean ghost_,
    boolean fixed_
    )
    {
      w = w_;
      h = h_;
      
      boundingBoxOffset = boundingBoxOffset_;
      
      mass = mass_;
      
      x = x_;
      y = y_;

      xbb = x + boundingBoxOffset;
      ybb = y + boundingBoxOffset;
      wbb = w - 2 * boundingBoxOffset;
      hbb = h - 2 * boundingBoxOffset;

      xt = PApplet.parseInt(xbb / TILE_SIZE);
      yt = PApplet.parseInt(ybb / TILE_SIZE);
      xc = PApplet.parseInt(xbb / chunkPix);
      yc = PApplet.parseInt(ybb / chunkPix);
      
      xbbLast = xbb;
      ybbLast = ybb;
      
      xtLast = xt;
      ytLast = yt;
      
      xcLast = xc;
      ycLast = yc;
      
      xcenter = x + w / 2; 
      ycenter = y + w / 2;
      
      xtcenter = PApplet.parseInt(xcenter / TILE_SIZE);
      ytcenter = PApplet.parseInt(ycenter / TILE_SIZE);
      
      vx = vx_;
      vy = vy_;
      vmax = vmax_;
      ax = ax_;
      ay = ay_;
      amax = amax_;
      friction = friction_;
      c_h = c_h_;
      c_s = c_s_;
      c_b = c_b_;
      ghost = ghost_;
      fixed = fixed_;
      
      // Add to Tile and Chunk entityLists.
      tiles[xt][yt].entityList.add(this);
      chunks[xc][yc].entityList.add(this);
    }
    
  ////////////////////////////////////////////////////////////////////////////////////
  public void update()
  {
    // Overwritten by derived classes.
    updatePhysics();
  }
    
  ////////////////////////////////////////////////////////////////////////////////////
  public void updatePhysics()
  {
    if(!fixed)
    {
      // Add acceleration and friction contributions to velocity.
      vx = constrain(vx + dt * (ax - sign(vx) * friction), -vmax, vmax);
      vy = constrain(vy + dt * (ay - sign(vy) * friction), -vmax, vmax);
      
      // If vx or vy are very small, threshold to 0.
      float vcutoff = 0.001f;
      if(abs(vx) < vcutoff)
      {
        vx = 0;
      }
      if(abs(vy) < vcutoff)
      {
        vy = 0;
      }
    
      // Zero out force.
      ax = 0;
      ay = 0;
    
      if(vx != 0 || vy != 0 || ax != 0 || ay != 0)
      {
        move(dt * vx, dt * vy);
      }
    }
  }
  
  //////////////////////////////////////////////////////////////////////////////////////
  public void display()
  {
    noStroke();
    pushMatrix();
    translate(-screenX, -screenY);
    
    // For now just draw a rectangle with a uniform fill.
    fill(c_h, c_s, c_b);
    //stroke(c_h, c_s, c_b);
    //strokeWeight(1);
    rect(x, y, w, h); 
    
    popMatrix();
  }
  
  //////////////////////////////////////////////////////////////////////////////////////
  public void display2()
  {
    float xsheet0;
    float xsheet1;
    float ysheet0;
    float ysheet1;
    boolean flipped = false;
    
    if(orientation == O_L || orientation == O_DR || orientation == O_UL)
    {
      flipped = true;
    }
    
    if(orientation == O_D)
    {
      ysheet0 = 0;
    }
    else if(orientation == O_R || orientation == O_L)
    {
      ysheet0 = 25;
    }
    else if(orientation == O_U)
    {
      ysheet0 = 50;
    }
    else if(orientation == O_DR || orientation == O_DL)
    {
      ysheet0 = 75;
    }
    else //if(orientation == O_UR || orientation == O_UL)
    {
      ysheet0 = 100;
    }
    
    ysheet1 = ysheet0 + 23;
    
    xsheet0 = floor(animationState) * 17;
    
    if(flipped)
    {
      xsheet1 = xsheet0;
      xsheet0 = xsheet1 + 15;
    }    
    else
    {
      xsheet1 = xsheet0 + 15;
    }
    
    noStroke();
    //pushMatrix();
    //translate(-screenX, -screenY);
    tint(c_b);
    beginShape();
    texture(playerSheet);
    vertex(x - screenX, y - screenY, xsheet0, ysheet0);
    vertex(x + w - screenX, y - screenY, xsheet1, ysheet0);
    vertex(x + w - screenX, y + h - screenY, xsheet1, ysheet1);
    vertex(x - screenX, y + h - screenY, xsheet0, ysheet1);
    endShape();
    
    //fill(0, 0, 1);
    //ellipse(xcenter, ycenter, 3, 3);
    
    //popMatrix();
    
  }
  
  //////////////////////////////////////////////////////////////////////////////////////
  public void tileListCheck()
  {
    // Called during move(). Checks to see if a new position will change which Tile the
    // Entity is in, and updates Tile entityLists if so.
    
    if(xtLast != xt || ytLast != yt)
    {
      tiles[xtLast][ytLast].entityList.remove(this);
      tiles[xt][yt].entityList.add(this);
    }
  }
  
  //////////////////////////////////////////////////////////////////////////////////////
  public void chunkListCheck()
  {
    // Called during move(). Checks to see if a new position will change which Chunk the
    // Entity is in, and updates Chunk entityLists if so.
    
    if(xcLast != xc || ycLast != yc)
    {
      chunks[xcLast][ycLast].entityList.remove(this);
      chunks[xc][yc].entityList.add(this);
    }
  }
  
  //////////////////////////////////////////////////////////////////////////////////////
  public void move(float dx, float dy)
  {
    float[] newPosition = {0,0};
    
    if(ghost) // No collisions for ghosts!
    {
      newPosition[0] = xbb + dx;
      newPosition[1] = ybb + dy;
    }
    else // Check for collisions.
    {
      newPosition = tileCollisionCheck(dx, dy);
    }
    
    // Save previous position variable values.
    xbbLast = xbb;
    ybbLast = ybb;
    xtLast = xt;
    ytLast = xt;
    xcLast = xc;
    ycLast = yc;
    
    // Update position variables.
    xbb = newPosition[0];
    ybb = newPosition[1];
    
    x = xbb - boundingBoxOffset;
    y = ybb - boundingBoxOffset;
    
    // Animate the Entity.
    animate();    
    
    // Update xt and yt.
    xt = PApplet.parseInt(x / TILE_SIZE);
    yt = PApplet.parseInt(y / TILE_SIZE);
    
    // Update xc and yc.
    xc = PApplet.parseInt(x / chunkPix);
    yc = PApplet.parseInt(y / chunkPix);
    
    // Check to see if newPosition changes which Tile and/or Chunk the Entity is in.
    tileListCheck();
    chunkListCheck();
    
    xcenter = x + w / 2;
    ycenter = y + h / 2;
    
    xtcenter = PApplet.parseInt(xcenter / TILE_SIZE);
    ytcenter = PApplet.parseInt(ycenter / TILE_SIZE);
  }
  
  //////////////////////////////////////////////////////////////////////////////
  public float[] tileCollisionCheck(float dx, float dy)
  {
    // Behavior will probably get weird at speeds exceeding wbb pixels/frame.
    
    // Return the new Entity (x,y) in this array.
    float[] newPosition = {0,0};
    
    // Calculate the coordinates of the Entity's 4 corners in the tentative new position.
    float xw0 = xbb + dx;
    float xw1 = xw0 + wbb;
    float yw0 = ybb + dy;
    float yw1 = yw0 + hbb;
    
    // An Entity can intersect 1, 2, or 4 Tiles, depending on whether the x coordinates of the Entity's corners
    // are in the same Tile and whether the y coordinates are in the same Tile. Track this to help collision resolution.
    boolean twoTilesX = false;
    boolean twoTilesY = false;
    
    // The Tile x coordinates of the Tiles containing the Entity's corners.
    int xt0 = PApplet.parseInt(xw0) / TILE_SIZE;
    int xt1 = PApplet.parseInt(xw1) / TILE_SIZE;
    
    // If xt0 != xt1, two different x Tile coordinates needed.
    if(xt0 != xt1)
    {
      twoTilesX = true;
    }
    
    // The Tile y coordinates of the Tiles containing the Entity's corners.
    int yt0 = PApplet.parseInt(yw0) / TILE_SIZE;
    int yt1 = PApplet.parseInt(yw1) / TILE_SIZE;    
    
    // If yt0 != yt1, two different y Tile coordinates needed.
    if(yt0 != yt1)
    {
      twoTilesY = true;
    }
    
    newPosition[0] = xw0;
    newPosition[1] = yw0;
    
    // Single Tile collision check
    if(!twoTilesX && !twoTilesY)
    {
      
      if(tiles[xt0][yt0].blocked)
      {
        // new Tile is blocked, just stay in the previous position.
        newPosition[0] = xbb;
        newPosition[1] = ybb;
      }
    }
    
    // Two Tile collision check, vertical separation.
    else if(twoTilesX && !twoTilesY)
    {
      if(tiles[xt0][yt0].blocked)
      {
        // Blocked left. Shift right.
        newPosition[0] = xt1 * TILE_SIZE + 0.0001f;
      }
      else if(tiles[xt1][yt0].blocked)
      {
        // Blocked right, shift left.
        newPosition[0] = xw0 - (xw1 - xt1 * TILE_SIZE + 0.0001f);
      }
    }
    
    // Two Tile collision check, horizontal separation.
    else if(!twoTilesX && twoTilesY)
    {      
      if(tiles[xt0][yt0].blocked)
      {
        // Blocked top. Shift down.
        newPosition[1] = yt1 * TILE_SIZE + 0.0001f;
      }
      else if(tiles[xt0][yt1].blocked)
      {
        // Blocked bottom. Shift up.
        newPosition[1] = yw0 - (yw1 - yt1 * TILE_SIZE + 0.0001f);
      }
    }
    
    // Four Tile collision check.
    else
    {
      // Check for collisions with blocked Tiles.
      boolean blocked00 = tiles[xt0][yt0].blocked;
      boolean blocked01 = tiles[xt0][yt1].blocked;
      boolean blocked10 = tiles[xt1][yt0].blocked;
      boolean blocked11 = tiles[xt1][yt1].blocked;
      
      // Check 1-block intersections.
      
      
      // Upper-left ********
      if(blocked00 && !blocked01 && !blocked10 && !blocked11)
      {
        float collisionWidth = xt1 * TILE_SIZE - xw0;
        float collisionHeight = yt1 * TILE_SIZE - yw0;
        boolean widthGreaterThanHeight = collisionWidth >= collisionHeight;

        if(!widthGreaterThanHeight && dx < 0)
        {
          newPosition[0] = xt1 * TILE_SIZE + 0.0001f;
        }
        else if(widthGreaterThanHeight && dy < 0)
        {
          newPosition[1] = yt1 * TILE_SIZE + 0.0001f;
        }
      }
      
      // Lower-left ********
      else if(!blocked00 && blocked01 && !blocked10 && !blocked11)
      {
        float collisionWidth = xt1 * TILE_SIZE - xw0;
        float collisionHeight = yw1 - yt1 * TILE_SIZE;
        boolean widthGreaterThanHeight = collisionWidth >= collisionHeight;
        
        if(!widthGreaterThanHeight && dx < 0)
        {
          newPosition[0] = xt1 * TILE_SIZE + 0.0001f;
        }
        else if(widthGreaterThanHeight && dy > 0)
        {
          newPosition[1] = yw0 - (yw1 - yt1 * TILE_SIZE + 0.0001f);
        }
      }
      
      // Upper-right ********
      else if(!blocked00 && !blocked01 && blocked10 && !blocked11)
      {
        float collisionWidth = xw1 - xt1 * TILE_SIZE;
        float collisionHeight = yt1 * TILE_SIZE - yw0;
        boolean widthGreaterThanHeight = collisionWidth >= collisionHeight;
        
        if(!widthGreaterThanHeight && dx > 0)
        {
          newPosition[0] = xw0 - (xw1 - xt1 * TILE_SIZE + 0.0001f);
        }
        else if(widthGreaterThanHeight && dy < 0)
        {
          newPosition[1] = yt1 * TILE_SIZE + 0.0001f;
        }
      }
      
      // Lower-right ********
      else if(!blocked00 && !blocked01 && !blocked10 && blocked11)
      {
        float collisionWidth = xw1 - xt1 * TILE_SIZE;
        float collisionHeight = yw1 - yt1 * TILE_SIZE;
        boolean widthGreaterThanHeight = collisionWidth >= collisionHeight;
        
        if(!widthGreaterThanHeight && dx > 0)
        {
          newPosition[0] = xw0 - (xw1 - xt1 * TILE_SIZE + 0.0001f);
        }
        else if(widthGreaterThanHeight && dy > 0)
        {
          newPosition[1] = yw0 - (yw1 - yt1 * TILE_SIZE + 0.0001f);
        }
      }
      
      // Two or more blocked Tiles ********
      else
      {    
        // Vertical blockage on the left
        if(blocked00 && blocked01)
        {
          newPosition[0] = xt1 * TILE_SIZE + 0.0001f;
        }
        
        // vertical blockage on the right
        else if(blocked10 && blocked11)
        {
          newPosition[0] = xw0 - (xw1 - xt1 * TILE_SIZE + 0.0001f);
        }
        
        // horizontal blockage on top
        if(blocked00 && blocked10)
        {
          newPosition[1] = yt1 * TILE_SIZE + 0.0001f;
        }
        
        // horizontal blockage on bottom
        if(blocked01 && blocked11)
        {
          newPosition[1] = yw0 - (yw1 - yt1 * TILE_SIZE + 0.0001f);
        }
      }
    }
    
    // Constrain each Entity to lie between the second and second-to-last Tiles.
    newPosition[0] = constrain(newPosition[0], TILE_SIZE, (tilesX - 2) * TILE_SIZE);
    newPosition[1] = constrain(newPosition[1], TILE_SIZE, (tilesY - 2) * TILE_SIZE);
    return newPosition;
  }
  
  //////////////////////////////////////////////////////////////////////////////
  public void animate()
  {
    char orientationNew;
    float dx = xbb - xbbLast;
    float dy = ybb - ybbLast;
    
    if(dx == 0 && dy == 0)
    {
      // No movement. Same orientation, reset animationState.
      
      orientationNew = orientation;
      
      // reset to this instead of 0 so that there is a change in animation on the first frame of a movement.
      animationState = PApplet.parseFloat(framesPerState - 1) / framesPerState;
    }
    else 
    {
      if(dx > 0 && dy == 0)
      {
        // Motion right.
        orientationNew = O_R;
      }
      else if(dx < 0 && dy == 0)
      {
        // Motion left.        
        orientationNew = O_L;
      }
      else if(dx == 0 && dy > 0)
      {
        // Motion down.       
        orientationNew = O_D;
      }
      else if(dx == 0 && dy < 0)
      {
        // Motion up.        
        orientationNew = O_U;
      }
      else if(dx > 0 && dy > 0)
      {
        // Motion down and right.
        orientationNew = O_DR;
      }
      else if(dx < 0 && dy > 0)
      {
        // Motion down and left.
        orientationNew = O_DL;
      }
      else if(dx > 0 && dy < 0)
      {
        // Motion up and right.
        orientationNew = O_UR;
      }
      else
      {
        // Motion up and left.
        orientationNew = O_UL;
      }
      
      // Update animation state.
      animationStateUpdate(orientationNew);
    }
    
      
  }
  
  //////////////////////////////////////////////////////////////////////////////
  public void animationStateUpdate(char orientation_)
  {
    if(orientation_ != orientation)
    {
      // If orientation has changed, reset animation state.
        
      animationState = 1;
      orientation = orientation_;
    }
    else
    {      
      int numStates;
      if(orientation == O_U || orientation == O_R || orientation == O_D || orientation == O_L)
      {
        numStates = 8;
      }
      else if(orientation == O_DL || orientation == O_DR)
      {
        numStates = 4;
      }
      else
      {
        numStates = 5;
      }
      
      // Advance animation state.
      animationState = 1 + (((animationState-1) + 1.f/framesPerState) % numStates);
    }
  }
  
  //////////////////////////////////////////////////////////////////////////////
  public void addS(float dx_, float dy_)
  {
    // Additively modify the Entity's position.
    
    x = constrain(x + dx_, 1, pixWidth - TILE_SIZE - w);
    y = constrain(y + dy_, 1, pixHeight - TILE_SIZE - h);
  }
  
  ///////////////////////////////////////////////////////////////////////////////
  public void addV(float dvx_, float dvy_)
  {
    // Additively modify the Entity's velocity.
    
    vx = constrain(vx + dvx_, -vmax, vmax);
    vy = constrain(vy + dvy_, -vmax, vmax);
  }
  
  ///////////////////////////////////////////////////////////////////////////////
  public void addP(float dpx_, float dpy_)
  {
    // Additively modify the Entity's momentum.
    // Same as addV() but weighted by mass.
    
    if(mass > 0)
    {
      // divide dp through by mass
      addV(dpx_/mass, dpy_/mass);
    }
    else
    {
      // mass is 0 or negative. Just treat it
      // as if mass = 1.
      addV(dpx_, dpy_);
    }
  }
  
  //////////////////////////////////////////////////////////////////////////////
  public void addA(float dax_, float day_)
  {
    // Additively modify the Entity's acceleration.
    
    ax = constrain(ax + dax_, -amax, amax);
    ay = constrain(ay + day_, -amax, amax);
  }
  
  //////////////////////////////////////////////////////////////////////////////
  public void addF(float dfx_, float dfy_)
  {
    // Apply an additive force to the Entity.
    // Same as addA() but weighted by mass.
    
    if(mass > 0)
    {
      // divide dp through by mass
      addA(dfx_/mass, dfy_/mass);
    }
    else
    {
      // mass is 0 or negative. Just treat it
      // as if mass = 1.
      addA(dfx_, dfy_);
    }
  }
  
}


// ************************************************
// ************************************************
class HUD
{
  // List of all HUDBars the HUD contains.
  ArrayList<HUDBar> barList;
  
  // List of all HUDMessages
  ArrayList<HUDMessage> messages;
  
  float healthBarLength = 128;
  float healthBarHeight = 16;
  
  float chargeBarLength = 200;
  float chargeBarHeight = 30;
  int chargeBarColor = color(0, 0, 0.2f, 0.4f);
  int chargeBarOutlineColor = color(0, 0, 0.8f, 0.7f); 
  int chargeBarFillColor = color(0.6f, 1, 1, 0.7f);
  int chargeBarX = round(0.5f * width - 0.5f * chargeBarLength);
  int chargeBarY = height - ((int)chargeBarHeight + 50);
   
  HUDBar chargeBar;
  
  HUD()
  {
     barList = new ArrayList<HUDBar>();
     messages = new ArrayList<HUDMessage>();
     chargeBar = new HUDBar(chargeBarX, chargeBarY, chargeBarLength, chargeBarHeight, chargeBarColor, chargeBarOutlineColor, chargeBarFillColor);
     barList.add(chargeBar);
     //healthBar = new HUDBar(x, y, healthBarLength, healthBarHeight, c_base, 1, c_outline, c_fill, 1);
     //barList.add(healthBar);
  }
  
  public void addMessage(float xc_, float yc_, String content_, float lifetime_) {
    HUDMessage message = new HUDMessage(xc_, yc_, content_, lifetime_);
    messages.add(message);
  }
  
  public void update() {
    chargeBar.howFull = player.charge / player.maxCharge;  
  }
  
  public void display() {
    
    for (int i = 0; i < messages.size(); i++) {
      messages.get(i).display();  
    }
    textAlign(LEFT);
    // Draw all hudBars
    for(int i = 0; i < barList.size(); i++) {
      barList.get(i).drawBar();
    }
    
    if (debugMode) {
      int fontSize = 24;
      int linePadding = 10;
      
      fill(0, 0, 1);
      textSize(fontSize);
      String[] debugMessages = {
        "t: " + nf(PApplet.parseInt(t)),
        "glow: " + nf(player.glowActive, 0, 2) + "  charge: " + nf(player.charge, 0, 2) + "  beatSize: " + nf(player.beatSize, 0, 2),
        "(xt,yt,xc,yc,b): (" + nf(PApplet.parseInt(player.xt)) + ", " + nf(PApplet.parseInt(player.yt)) + ", " + nf(PApplet.parseInt(player.xc)) + ", " + nf(PApplet.parseInt(player.yc)) + ", " + nf(player.c_b, 0, 2) + ")",
        "orientation: " + nf(PApplet.parseInt(player.orientation)) + "  animationState: " + nf(player.animationState, 0, 2),
        "ghost: " + nf(PApplet.parseInt(player.ghost)) + "  dead: " + nf(PApplet.parseInt(player.dead))
      };
      for(int i = 0; i < debugMessages.length; i++) {
        text(debugMessages[i], round(0.03f * width), round(0.08f * height) + i * (fontSize + linePadding));
      }
    }
    
  }
}


class HUDMessage {
  // Message center coordinates
  float xc, yc;  
  String content;
  float lifetime;
  float t0;
  
  HUDMessage(float xc_, float yc_, String content_, float lifetime_) {
    xc = xc_;
    yc = yc_;
    content = content_;
    lifetime = lifetime_;
    t0 = t;
  }
  
  public void display() {
    textAlign(CENTER);
    float dt = (t - t0) / lifetime;
    if (dt > 1) {
      hud.messages.remove(this);
    } else {
      textSize(20);
      fill(0, 0, 1, 1 - pow(dt, 3));
      text(content, xc - screenX, yc - screenY);
    }
  }
}


// ************************************************
// ************************************************
class HUDRectangle
{
  // A visible rectangle in the HUD. 
  
  // (x,y) screen coordinates of the top-left corner of the HUDRectangle.
  float x, y;
  
  // Length of the HUDRectangle.
  float L;
  
  // Height of the HUDRectangle.
  float H;
  
  // HUDRectangle's body's color. HSB coordinates in [0,1].
  int c_body;
  
  // HUDRectangle's outline's stroke weight.
  float outlineWeight;
  
  // HUDRectangle's outline's color. HSB coordinates in [0,1].
  int c_outline;
  
  /////////////////////////////////////////////////////////////////////////////////////////////////
  HUDRectangle(
    float x_, 
    float y_, 
    float L_, 
    float H_, 
    int c_body_, 
    float outlineWeight_,
    int c_outline_
  )
  {
    x = x_;
    y = y_;
    L = L_;
    H = H_;
    c_body = c_body_;
    outlineWeight = outlineWeight_;
    c_outline = c_outline_;
  }
  
  public void drawRectangle()
  {
    stroke(c_outline);
    strokeWeight(outlineWeight);
    fill(c_body);
    rect(x, y, L, H);
  }
}

// ***********************************************
// ***********************************************
class HUDBar extends HUDRectangle
{
  // A HUDBar is a meter that tracks e.g. player health, player energy,
  // displaying a proportion of a maximum quantity (e.g. health/maxHealth).
  // The display has a proportionately-sized rectangle of color c_fill on
  // top of a full-sized background rectangle of color c_body.
  
  int c_fill;
  
  float howFull;
  
  ///////////////////////////////////////////////////////////////////////////////////////////////
  HUDBar(
    float x_, 
    float y_, 
    float L_, 
    float H_, 
    int c_body_, 
    int c_outline_,
    int c_fill_
  )
  {
    super(x_, y_, L_, H_, c_body_, 1, c_outline_);
    c_fill = c_fill_;
    howFull = 0;
  }
  
  /////////////////////////////////////////////////////////////////////////////////////////////////
  public void drawBar()
  {
    // Draw the base HUDRectangle.
    drawRectangle();
    
    strokeWeight(0); // No outline.
    
    fill(c_fill);
    
    // Draw the additional rectangle measuring fullness.
    rect(x, y, howFull * L, H);
  }
}
    
    
  
interface Item
{
  // Triggered when the item is picked up
  public void pickUp();
  // Item display function
  public void display();  
  // Add Item to Tiles
  public void addToTiles();
}


class ItemStaminaBoost implements Item {
  // (x,y) World coordinates of the Item's center.
  float xc, yc;
  // (x, y) Tile coordinates
  int xt, yt;
  // Width and Height of the Item.
  float w, h;
  // HSB color coordinates of this Item. Range [0,1].
  float c_h, c_s, c_b;
  
  // Restore strength
  float strength;
  
  ItemStaminaBoost(int xt_, int yt_) {
    xt = xt_;
    yt = yt_;
    w = PApplet.parseFloat(TILE_SIZE / 4);
    h = PApplet.parseFloat(TILE_SIZE / 4);
    xc = xt * TILE_SIZE + TILE_SIZE / 2;
    yc = yt * TILE_SIZE + TILE_SIZE / 2;
    c_h = 0;
    c_s = 0;
    c_b = 0.95f;
    
    strength = max(0.03f, random(1) * random(1));
    
    addToTiles();
  }
  
  public void pickUp() {
    player.chargeCost += 0.33f * strength * (1 - player.chargeCost);
    tiles[xt][yt].itemList.remove(this);
    hud.addMessage(xc, yc - TILE_SIZE, "Glow Stamina +" + str(round(100 * strength)) + "%", 2);
  }
  
  public void display() {
    float tile_b = tiles[xt][yt].final_b;
    float beatStrength = heartbeat(t, strength, 1);
    float cr = 1 + 0.75f * beatStrength;
    float itemBrightness = constrain((4 + 6 * beatStrength) * tile_b + 0.001f, 0, 1);
    
    stroke(0, 0, 0);
    strokeWeight(1);
    fill(c_h, c_s, itemBrightness);
    ellipse(xc - screenX, yc - screenY, cr * w, cr * h);
  }
  
  public void addToTiles() {

    // Top-left corner Tile
    tiles[xt][yt].itemList.add(this);
  }
}


class ItemChargeBoost implements Item {
  // (x,y) World coordinates of the Item's center.
  float xc, yc;
  // (x, y) Tile coordinates
  int xt, yt;
  // Width and Height of the Item.
  float w, h;
  // HSB color coordinates of this Item. Range [0,1].
  float c_h, c_s, c_b;
  
  // Restore strength
  float strength;
  
  ItemChargeBoost(int xt_, int yt_) {
    xt = xt_;
    yt = yt_;
    w = PApplet.parseFloat(TILE_SIZE / 4);
    h = PApplet.parseFloat(TILE_SIZE / 4);
    xc = xt * TILE_SIZE + TILE_SIZE / 2;
    yc = yt * TILE_SIZE + TILE_SIZE / 2;
    c_h = 0.33f;
    c_s = 0.9f;
    c_b = 0.8f;
    
    strength = random(1) * random(1);
    
    addToTiles();
  }
  
  public void pickUp() {
    player.maxCharge = (1 + strength) * player.maxCharge;
    player.charge = (1 + strength) * player.charge;
    tiles[xt][yt].itemList.remove(this);
    hud.addMessage(xc, yc - TILE_SIZE, "Max Charge +" + str(round(100 * strength)) + "%", 2);
  }
  
  public void display() {
    float tile_b = tiles[xt][yt].final_b;
    float beatStrength = heartbeat(t, strength, 1);
    float cr = 1 + 0.75f * beatStrength;
    float itemBrightness = constrain((4 + 6 * beatStrength) * tile_b + 0.001f, 0, 1);
    
    stroke(0, 0, 0);
    strokeWeight(1);
    fill(c_h, c_s, itemBrightness);
    ellipse(xc - screenX, yc - screenY, cr * w, cr * h);
  }
  
  
  public void addToTiles() {

    // Top-left corner Tile
    tiles[xt][yt].itemList.add(this);
  }
}


class ItemGlowBoost implements Item {
  // (x,y) World coordinates of the Item's center.
  float xc, yc;
  // (x, y) Tile coordinates
  int xt, yt;
  // Width and Height of the Item.
  float w, h;
  // HSB color coordinates of this Item. Range [0,1].
  float c_h, c_s, c_b;
  
  // Restore strength
  float strength;
  
  ItemGlowBoost(int xt_, int yt_) {
    xt = xt_;
    yt = yt_;
    w = PApplet.parseFloat(TILE_SIZE / 4);
    h = PApplet.parseFloat(TILE_SIZE / 4);
    xc = xt * TILE_SIZE + TILE_SIZE / 2;
    yc = yt * TILE_SIZE + TILE_SIZE / 2;
    c_h = 0;
    c_s = 1;
    c_b = 1;
    
    strength = random(1) * random(1);
    
    addToTiles();
  }
  
  public void pickUp() {
    player.glow = min(player.maxGlow, (1 + strength) * player.glow);
    tiles[xt][yt].itemList.remove(this);
    
    if (player.glow == player.maxGlow) {
      hud.addMessage(xc, yc - TILE_SIZE, "Glow at max", 2);    
    } else {
      hud.addMessage(xc, yc - TILE_SIZE, "Glow +" + str(round(100 * strength)) + "%", 2);
    }
  }
  
  public void display() {
    float tile_b = tiles[xt][yt].final_b;
    float beatStrength = heartbeat(t, strength, 1);
    float cr = 1 + 0.75f * beatStrength;
    float itemBrightness = constrain((4 + 6 * beatStrength) * tile_b + 0.001f, 0, 1);
    
    stroke(0, 0, 0);
    strokeWeight(1);
    fill(c_h, c_s, itemBrightness);
    ellipse(xc - screenX, yc - screenY, cr * w, cr * h);
  }
  
  
  public void addToTiles() {

    // Top-left corner Tile
    tiles[xt][yt].itemList.add(this);
  }
}


class ItemChargeRestore implements Item {
  // (x,y) World coordinates of the Item's center.
  float xc, yc;
  // (x, y) Tile coordinates
  int xt, yt;
  // Width and Height of the Item.
  float w, h;
  // HSB color coordinates of this Item. Range [0,1].
  float c_h, c_s, c_b;
  
  // Restore strength
  float strength;
  
  ItemChargeRestore(int xt_, int yt_) {
    xt = xt_;
    yt = yt_;
    w = PApplet.parseFloat(TILE_SIZE / 4);
    h = PApplet.parseFloat(TILE_SIZE / 4);
    xc = xt * TILE_SIZE + TILE_SIZE / 2;
    yc = yt * TILE_SIZE + TILE_SIZE / 2;
    c_h = 0.6f;
    c_s = 0.85f;
    c_b = 0.9f;
    
    strength = random(1) * random(1);
    
    addToTiles();
  }
  
  public void pickUp() {
    player.charge = min(player.maxCharge, player.charge + strength * player.maxCharge);
    tiles[xt][yt].itemList.remove(this);
    
    hud.addMessage(xc, yc - TILE_SIZE, "Charge +" + str(round(100 * strength)), 2);    
  }
  
  public void display() {
    float tile_b = tiles[xt][yt].final_b;
    float beatStrength = heartbeat(t, strength, 1);
    float cr = 1 + 0.75f * beatStrength;
    float itemBrightness = constrain((4 + 6 * beatStrength) * tile_b + 0.001f, 0, 1);
    
    stroke(0, 0, 0);
    strokeWeight(1);
    fill(c_h, c_s, itemBrightness);
    ellipse(xc - screenX, yc - screenY, cr * w, cr * h);
  }
  
  
  public void addToTiles() {

    // Top-left corner Tile
    tiles[xt][yt].itemList.add(this);
  }
}


// ****************************************
// ****************************************
class ItemHealth implements Item
{
  // (x,y) World coordinates of the Item's upper-left corner.
  float x, y;
  // (x, y) Tile coordinates
  int xt, yt;
  // Width and Height of the Item.
  float w, h;
  // HSB color coordinates of this Item. Range [0,1].
  float c_h, c_s, c_b;
  
  // Amount of health this Item restores
  float healthAmount;
  
  ////////////////////////////////////////////////////////////////////////////////
  ItemHealth(float x_, float y_)
  {
    x = x_;
    y = y_;
    xt = round(x / TILE_SIZE);
    yt = round(y / TILE_SIZE);
    w = PApplet.parseFloat(TILE_SIZE)/2;
    h = PApplet.parseFloat(TILE_SIZE)/2;
    
    healthAmount = 15;
    
    c_h = 0;
    c_s = 1;
    c_b = 1;
    
    // Add a function to add the Item to the itemLists of the Tiles which the Item intersects.
  }
  
  //////////////////////////////////////////////////////////////////////////////////
  public void pickUp()
  {
    player.addHealth(healthAmount);
  }
  
  ///////////////////////////////////////////////////////////////////////////////////
  public void display()
  {
    noStroke();
    pushMatrix();
    translate(-screenX, -screenY);
    
    // For now just draw a rectangle with a uniform fill.
    fill(c_h, c_s, c_b);
    rect(x, y, w, h); 
    
    popMatrix();
  }
  
  ////////////////////////////////////////////////////////////////////////////////////
  public void addToTiles() {
    // Add this Item to all the Tiles which it intersects.
    
    // Tile coordinates of the Item's four corners.
    int xt0 = PApplet.parseInt(x / TILE_SIZE);
    int yt0 = PApplet.parseInt(y / TILE_SIZE);
    int xt1 = PApplet.parseInt((x + w) / TILE_SIZE);
    int yt1 = PApplet.parseInt((y + h) / TILE_SIZE); 
    
    // Top-left corner Tile
    tiles[xt0][yt0].itemList.add(this);
    
    if(yt1 != yt0)
    {
      // Bottom corners aren't in the same Tile as top corners.
      
      tiles[xt0][yt1].itemList.add(this);
      
      if(xt1 != xt0)
      {
        // Also, right corners aren't in the same Tile as left corners.
        
        tiles[xt1][yt0].itemList.add(this);
        tiles[xt1][yt1].itemList.add(this);
      }
    }
    else if(xt1 != xt0)
    {
      // Right corners aren't in the same Tile as left corners.
      
      tiles[xt1][yt0].itemList.add(this);
    }    
  }
    
  }
// Plans are generative procedures for Chunks and Tiles - creating or altering Tiles, Entities, Items, etc. given some numerical input data.
interface Plan
{
   public void run(int seed);
}

// ***************************************
// ***************************************
class TilePlan implements Plan
{
  // TilePlan changes N Tiles within the Chunk specified in run(), to 
  // specified types at specified locations, relative to the input
  // Chunk's top-left corner.
  
  IntList tileCoordinatesX;
  IntList tileCoordinatesY;
  IntList tileTypes;
  
  float xw0, yw0;
  
  /////////////////////////////////////////////////////////////////////////////////////////
  TilePlan(float xw0_, float yw0_)
  {
    xw0 = xw0_;
    yw0 = yw0_;
    
    tileCoordinatesX = new IntList();
    tileCoordinatesY = new IntList();
    tileTypes = new IntList();
  }
  
  //////////////////////////////////////////////////////////////////////////////////////////
  public void addTile(int xt_, int yt_, int type_)
  {
    tileCoordinatesX.append(xt_);
    tileCoordinatesY.append(yt_);
    tileTypes.append(type_);
  }
  
  //////////////////////////////////////////////////////////////////////////////////////////
  public void removeTile(int xt_, int yt_)
  {
    // Checks to see if any Tile changed by the Plan has Tile coordinates 
    // (xt_,yt_), and removes it if so.
    for(int i = tileTypes.size() - 1; i >= 0; i--)
    {
      if( (tileCoordinatesX.get(i) == xt_) && (tileCoordinatesY.get(i) == yt_) )
      {
        tileCoordinatesX.remove(i);
        tileCoordinatesY.remove(i);
        tileTypes.remove(i);
      }
    }
  }      
  
  ///////////////////////////////////////////////////////////////////////////////////////////
  public void run(int seed)
  {
    // Get the Tile coordinates of the Tile containing the basepoint.
    int xt0 = PApplet.parseInt(xw0 / TILE_SIZE);
    int yt0 = PApplet.parseInt(yw0 / TILE_SIZE);
    
    for(int i = 0; i < tileTypes.size(); i++)
    {
      // Figure out absolute Tile coordinate of the Tile to change.
      int xtabs = xt0 + tileCoordinatesX.get(i);
      int ytabs = yt0 + tileCoordinatesY.get(i);
      
      // Set the new Tile type.
      tiles[xtabs][ytabs].setType(tileTypes.get(i));
      
    }
  }
}


class MazePlanDemo implements Plan {
  int[] numRoundsList = {10};
  int[] creatorsPerRoundList = {4};
  int[] numStartWinRoundsList = {2};
  
  
  MazePlanDemo(){}
  
  
  public void run(int seed) {  
    randomSeed(seed);
    
    baseHue = random(1);
    
    int numSizes = numRoundsList.length;
    
    for(int r = 0; r < numSizes; r++) {
      int numRounds = numRoundsList[r];
      int creatorsPerRound = creatorsPerRoundList[r];
      int numStartWinRounds = numStartWinRoundsList[r];
      
      int halfX = round(tilesOnScreenX / 2);
      int halfY = round(tilesOnScreenY / 2);
      
      xtstart = halfX + 1;
      ytstart = halfY + 1;
      xtwin = tilesX - halfX - 1;
      ytwin = tilesY - halfY - 1;
      //maxDistance = pow(xtwin * xtwin + ytwin * ytwin, 0.5);
      maxDistance = xtwin * xtwin + ytwin * ytwin;
      xwstart = (float)xtstart * TILE_SIZE;
      ywstart = (float)ytstart * TILE_SIZE;
      
      // Corridor width
      int corridorWidth = 1;
      
      for(int i = 0; i < numStartWinRounds; i++) {
        // Add 1 creator at the starting and the winning Tiles per round.
        
        ArrayList<Creator> creators = new ArrayList<Creator>();
        
        float directionBias = 0;
        float directionBiasStrength = 0;
        float winBias = 0.3f;
        float lengthMean = 6;
        float lengthSD = 5;
        int lengthMin = 1;
        float startAvoidProbability = 0.25f;
        float winAvoidProbability = 0.1f;
        char creatorDirection = PApplet.parseChar(PApplet.parseInt(random(0, 4)));
        int lifetime = 250;
        
        // Add starting and winning Creators.
        if (i < 2) {
          creators.add(new Creator(xtstart, ytstart, directionBias, directionBiasStrength, 0, -winBias, lengthMean, lengthSD, lengthMin, corridorWidth, startAvoidProbability, creatorDirection, lifetime));
        }
        creators.add(new Creator(xtwin, ytwin, directionBias, directionBiasStrength, -winBias, 0, lengthMean, lengthSD, lengthMin, corridorWidth, winAvoidProbability, creatorDirection, lifetime));
        
        runCreators(creators);
      } 
        
        
      for(int i = 0; i < numRounds; i++) {
        // Add the random Creators and run them.
        
        // Initialize the ArrayList for this round's Creators.
        ArrayList<Creator> creators = new ArrayList<Creator>(); 
        
        float directionBias = 0;
        float directionBiasStrength = 0;
        float bias = random(-0.1f/(i+1), 0.1f/(i+1));
        float lengthMean = 6;
        float lengthSD = 3;
        int lengthMin = 2;
        float avoidProbability = 0.27f + 0.7f * PApplet.parseFloat(i) / PApplet.parseFloat(numRounds);
        char creatorDirection = PApplet.parseChar(PApplet.parseInt(random(0, 4)));
        int lifetime = round(2 * sqrt(tilesX * tilesY) / 2);
        
        for(int j = 0; j < creatorsPerRound; j++) {          
          int xt0 = PApplet.parseInt(random(tilesX - 2)) + 1;
          int yt0 = PApplet.parseInt(random(tilesY - 2)) + 1;
          
          float rand = random(1);
          if (rand < 0.25f) {
            creators.add(new Creator(xt0, yt0, directionBias, directionBiasStrength, bias, 0, lengthMean, lengthSD, lengthMin, corridorWidth, avoidProbability, creatorDirection, lifetime));
          } else if (rand < 0.5f) {
            creators.add(new Creator(xt0, yt0, directionBias, directionBiasStrength, 0, bias, lengthMean, lengthSD, lengthMin, corridorWidth, avoidProbability, creatorDirection, lifetime));
          } else {
            creators.add(new Creator(xt0, yt0, directionBias, directionBiasStrength, 0, 0, lengthMean, lengthSD, lengthMin, corridorWidth, avoidProbability, creatorDirection, lifetime));  
          }
        }
      
        runCreators(creators);
      }
    }
  }
  
  
  public void runCreators(ArrayList<Creator> creators_)
  {
    // Let the Creators do their thing.
    while(creators_.size() > 0) 
    {
      // while any Creators are still alive
      
      // Move all the Creators in creators.
      for(int k = creators_.size()-1; k>=0; k--)
      {
        Creator aCreator = creators_.get(k);
        
        if(aCreator.lifeRemaining == 0)
        {
          // aCreator is dead.
          creators_.remove(k);
        }
        else
        {
          aCreator.move();
        }
      }
    }
  }
  
}


class MazePlan2 implements Plan {
  int[] numRoundsList = {round(1.f / 6 * CHUNKSX * CHUNKSY)};
  int[] creatorsPerRoundList = {4};
  int[] numStartWinRoundsList = {round(8.f / 900 * CHUNKSX * CHUNKSY)};
  
  
  MazePlan2(){}
  
  
  public void run(int seed) {  
    randomSeed(seed);
    
    baseHue = random(1);
    
    int numSizes = numRoundsList.length;
    
    for(int r = 0; r < numSizes; r++) {
      int numRounds = numRoundsList[r];
      int creatorsPerRound = creatorsPerRoundList[r];
      int numStartWinRounds = numStartWinRoundsList[r];
      
      int halfX = round(tilesOnScreenX / 2);
      int halfY = round(tilesOnScreenY / 2);
      
      xtstart = halfX + 1;
      ytstart = halfY + 1;
      xtwin = tilesX - halfX - 1;
      ytwin = tilesY - halfY - 1;
      //maxDistance = pow(xtwin * xtwin + ytwin * ytwin, 0.5);
      maxDistance = xtwin * xtwin + ytwin * ytwin;
      xwstart = (float)xtstart * TILE_SIZE;
      ywstart = (float)ytstart * TILE_SIZE;
      
      // Corridor width
      int corridorWidth = 1;
      
      for(int i = 0; i < numStartWinRounds; i++) {
        // Add 1 creator at the starting and the winning Tiles per round.
        
        ArrayList<Creator> creators = new ArrayList<Creator>();
        
        float directionBias = 0;
        float directionBiasStrength = 0;
        float winBias = 0.3f;
        float lengthMean = 6;
        float lengthSD = 5;
        int lengthMin = 1;
        float startAvoidProbability = 0.25f;
        float winAvoidProbability = 0.1f;
        char creatorDirection = PApplet.parseChar(PApplet.parseInt(random(0, 4)));
        int lifetime = 250;
        
        // Add starting and winning Creators.
        if (i < 2) {
          creators.add(new Creator(xtstart, ytstart, directionBias, directionBiasStrength, 0, -winBias, lengthMean, lengthSD, lengthMin, corridorWidth, startAvoidProbability, creatorDirection, lifetime));
        }
        creators.add(new Creator(xtwin, ytwin, directionBias, directionBiasStrength, -winBias, 0, lengthMean, lengthSD, lengthMin, corridorWidth, winAvoidProbability, creatorDirection, lifetime));
        
        runCreators(creators);
      } 
        
        
      for(int i = 0; i < numRounds; i++) {
        // Add the random Creators and run them.
        
        // Initialize the ArrayList for this round's Creators.
        ArrayList<Creator> creators = new ArrayList<Creator>(); 
        
        float directionBias = 0;
        float directionBiasStrength = 0;
        float bias = random(-0.1f/(i+1), 0.1f/(i+1));
        float lengthMean = 6;
        float lengthSD = 3;
        int lengthMin = 2;
        float avoidProbability = 0.27f + 0.7f * PApplet.parseFloat(i) / PApplet.parseFloat(numRounds);
        char creatorDirection = PApplet.parseChar(PApplet.parseInt(random(0, 4)));
        int lifetime = round(2 * sqrt(tilesX * tilesY) / 2);
        
        for(int j = 0; j < creatorsPerRound; j++) {          
          int xt0 = PApplet.parseInt(random(tilesX - 2)) + 1;
          int yt0 = PApplet.parseInt(random(tilesY - 2)) + 1;
          
          float rand = random(1);
          if (rand < 0.25f) {
            creators.add(new Creator(xt0, yt0, directionBias, directionBiasStrength, bias, 0, lengthMean, lengthSD, lengthMin, corridorWidth, avoidProbability, creatorDirection, lifetime));
          } else if (rand < 0.5f) {
            creators.add(new Creator(xt0, yt0, directionBias, directionBiasStrength, 0, bias, lengthMean, lengthSD, lengthMin, corridorWidth, avoidProbability, creatorDirection, lifetime));
          } else {
            creators.add(new Creator(xt0, yt0, directionBias, directionBiasStrength, 0, 0, lengthMean, lengthSD, lengthMin, corridorWidth, avoidProbability, creatorDirection, lifetime));  
          }
        }
      
        runCreators(creators);
      }
    }
  }
  
  
  public void runCreators(ArrayList<Creator> creators_)
  {
    // Let the Creators do their thing.
    while(creators_.size() > 0) 
    {
      // while any Creators are still alive
      
      // Move all the Creators in creators.
      for(int k = creators_.size()-1; k>=0; k--)
      {
        Creator aCreator = creators_.get(k);
        
        if(aCreator.lifeRemaining == 0)
        {
          // aCreator is dead.
          creators_.remove(k);
        }
        else
        {
          aCreator.move();
        }
      }
    }
  }
  
}


// **********************************************
// **********************************************
class MazePlan1 implements Plan
{
  int[] numRoundsList = {50};
  int[] creatorsPerRoundList = {5};
  int[] numStartWinRoundsList = {3};
  
  ///////////////////////////////////////////////////////////////////////////////////////
  MazePlan1()
  {
   
  }
  
  ///////////////////////////////////////////////////////////////////////////////////////
  public void run(int seed)
  {  
    randomSeed(millis());
    
    int numSizes = numRoundsList.length;
    
    for(int r = 0; r < numSizes; r++)
    {
      int numRounds = numRoundsList[r];
      int creatorsPerRound = creatorsPerRoundList[r];
      int numStartWinRounds = numStartWinRoundsList[r];
      
      xwstart = 10 * TILE_SIZE + TILE_SIZE / 2;
      ywstart = 10 * TILE_SIZE + TILE_SIZE / 2;
      xtstart = PApplet.parseInt(xwstart / TILE_SIZE);
      ytstart = PApplet.parseInt(ywstart / TILE_SIZE);
      xtwin = tilesX - PApplet.parseInt(floor(random(20, 80)));
      ytwin = tilesY - PApplet.parseInt(floor(random(20, 80)));
      
      // Make the winning Tile T_WIN
      //tiles[xtwin][ytwin].setType(T_WIN);
      
      // Corridor width
      int corridorWidth = 1;
      
      for(int i = 0; i < numStartWinRounds; i++)
      {
        // Add 1 creator at the starting and the winning Tiles per round.
        
        ArrayList<Creator> creators = new ArrayList<Creator>();
        
        float directionBias = 0;
        float directionBiasStrength = 0;
        float winBias = 0.66f;
        float lengthMean = 3;
        float lengthSD = 3;
        int lengthMin = 2;
        float startAvoidProbability = 0.25f + 0.7f * PApplet.parseFloat(i) / PApplet.parseFloat(numStartWinRounds);
        float winAvoidProbability = 0.1f;
        char creatorDirection = PApplet.parseChar(PApplet.parseInt(random(0, 4)));
        int lifetime = round(3 * sqrt(tilesX * tilesY) / 2);
        
        // Add starting and winning Creators.
        creators.add(new Creator(xtstart, ytstart, directionBias, directionBiasStrength, winBias, 0, lengthMean, lengthSD, lengthMin, corridorWidth, startAvoidProbability, creatorDirection, lifetime));
        creators.add(new Creator(xtwin, ytwin, directionBias, directionBiasStrength, -winBias, 0, lengthMean, lengthSD, lengthMin, corridorWidth, winAvoidProbability, creatorDirection, lifetime));
        
        runCreators(creators);
      } 
        
        
      for(int i = 0; i < numRounds; i++)
      {
        // Add the random Creators and run them.
        
        // Initialize the ArrayList for this round's Creators.
        ArrayList<Creator> creators = new ArrayList<Creator>(); 
        
        float directionBias = 0;
        float directionBiasStrength = 0;
        float winBias = random(-0.5f, 0.5f);
        float lengthMean = 3;
        float lengthSD = 3;
        int lengthMin = 2;
        float avoidProbability = 0.1f + 0.3f * PApplet.parseFloat(i) / PApplet.parseFloat(numRounds);
        char creatorDirection = PApplet.parseChar(PApplet.parseInt(random(0, 4)));
        int lifetime = round(3 * sqrt(tilesX * tilesY) / 2);
        
        for(int j = 0; j < creatorsPerRound; j++)
        {          
          int xt0 = PApplet.parseInt(random(tilesX - 2)) + 1;
          int yt0 = PApplet.parseInt(random(tilesY - 2)) + 1;
          
          creators.add(new Creator(xt0, yt0, directionBias, directionBiasStrength, winBias, 0, lengthMean, lengthSD, lengthMin, corridorWidth, avoidProbability, creatorDirection, lifetime));
        }
      
        runCreators(creators);
      }
    }
  }
  
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  public void runCreators(ArrayList<Creator> creators_)
  {
    // Let the Creators do their thing.
    while(creators_.size() > 0) 
    {
      // while any Creators are still alive
      
      // Move all the Creators in creators.
      for(int k = creators_.size()-1; k>=0; k--)
      {
        Creator aCreator = creators_.get(k);
        
        if(aCreator.lifeRemaining == 0)
        {
          // aCreator is dead.
          creators_.remove(k);
        }
        else
        {
          aCreator.move();
        }
      }
    }
  }
  
}
//color c_player = color(0.5, 1., 1.);
// Player color (HSB), range [0,1].
float player_h = 0.5f;
float player_s = 1.f;
float player_b = 0.3f;

class Player extends Entity
{
  float health;
  float maxHealth;
  
  float energy;
  float minEnergy;
  float maxEnergy;
  float energyCost; // Energy diminishes exponentially with this rate parameter.
  float energyRechargeRate; // Governs how quickly energy recharges.
  
  float glow;
  float glowInit;
  float glowActive;
  float maxGlow;
  
  float charge;
  float minCharge;
  float maxCharge;
  float chargeCost;
  float chargeRecharge;
  float chargeMultiplier;
  
  float beatRate;
  float beatRateMin;
  float beatRateMax;
  float dbRate;
  
  float beatSize;
  float beatSizeMax;
  float dbSize;
  
  // Player movement speed.
  float moveSpeed;
  
  ////////////////////////////////////////////////////////////////////////////////////////
  Player(float xw_, float yw_)
  {    
    super(
      30, // width
      45, // height
      3, // boundingBoxOffset
      1.f, // mass
      xw_, // x0
      yw_, // y0
      0.f, // vx0
      0.f, // vy0
      60.f, // vmax
      0.f, // ax0
      0.f, // ay0
      60.f, // amax
      1.f, // friction
      player_h, // c_h
      player_s, // c_s
      player_b, // c_b
      false, // ghost
      false // fixed
      );
    
    health = 50.f;
    maxHealth = 100.f;
    
    energy = 0.2f;
    maxEnergy = 0.2f;
    minEnergy = pow(10, -6);
    
    energyCost = 0.90f;
    energyRechargeRate = 1.001f;
    
    glow = 0.025f;
    glowInit = glow;
    glowActive = glow;
    maxGlow = 1000;
    
    beatRateMin = 0.2f;
    beatRateMax = 5;
    beatRate = beatRateMin;
    dbRate = (beatRateMax - beatRateMin) / 180;
    
    beatSize = 0;
    beatSizeMax = 0.5f;
    dbSize = beatSizeMax / 500;
    
    minCharge = pow(10, -6);
    maxCharge = 0.2f;
    chargeCost = 0.97f;
    chargeRecharge = 1.001f;  // TODO change back //////////////////////////////////////////////////////////////////////////////////////////////////////////////
    charge = maxCharge;
    chargeMultiplier = 0.1f;
    moveSpeed = 2.5f;
    
    alignment = A_FRIEND;
  }
  
  public void update()
  {
    
    if (world.state == W_PLAY && xt == xtwin && yt == ytwin && dist(xcenter, ycenter, xtwin * TILE_SIZE + TILE_SIZE / 2, ytwin * TILE_SIZE + TILE_SIZE / 2) < TILE_SIZE / 4) {
    //if (world.state == W_PLAY && xt == xtwin && yt == ytwin) {
      world.state = W_WIN;
      winTime = millis();
    }
    
    if (mousePressed) {
      glowActive += chargeMultiplier * charge;
      if (!player.ghost) {
        charge = max(minCharge, charge * chargeCost);
      }
    } else {
      charge = min(maxCharge, charge * chargeRecharge);
    }
    glowActive = max(glow, 0.98f * glowActive);
    // Light up the Tile that the player is centered on
    Tile tcenter = tiles[xtcenter][ytcenter];
    float glowNow = glowActive;// * (1 - beatSize * 0.5 * (cos(PI*t) + 1));
    tcenter.c_bactiveNew += glowNow;
    // Add a little light to its neighbor tiles
    for (int i = 0; i < tcenter.neighborList.size(); i++) {
        Tile tneighb = tcenter.neighborList.get(i);
        float txc = tneighb.xw + TILE_SIZE / 2;
        float tyc = tneighb.yw + TILE_SIZE / 2;
        float dsq = (pow(player.xcenter - txc, 2) + pow(player.ycenter - tyc, 2)) / pow(TILE_SIZE, 2);
        float glowScale = min(1, 1 / (dsq + 0.0001f));
        tneighb.c_bactiveNew += glowScale * glowNow;
    }
    
    int numItems = tcenter.itemList.size();
    if (numItems > 0) {
      for (int i = 0; i < numItems; i++) {
        tcenter.itemList.get(i).pickUp();  
      }
    }
    
    //float min_b = min(max(player_b, glow), 1);
    //c_b = constrain(min_b + (1 - player_b) * sigmoid(0.25*(glowActive - glow) / glow), 0, 1);
    if (!tcenter.blocked) {
      c_b = tcenter.final_b;
    }
    
    // Add that Tile to the lightList.
    lightList.addTile(tiles[xtcenter][ytcenter]);
    
    // Call Entity physics update.
    updatePhysics();
    
    beatSize = max(0, beatSize - 0.16f * dbSize);
    beatRate = max(beatRateMin, beatRate - 0.25f * dbRate);
  }
  
  //////////////////////////////////////////////////////////////////////////////////////////
  public void addHealth(float dhealth_)
  {
    health = constrain(health + dhealth_, 0, maxHealth);
  }
  
  //////////////////////////////////////////////////////////////////////////////////////////
  public void addEnergy(float denergy_)
  {
    energy = constrain(energy + denergy_, 0, maxEnergy);
  }
  
  public void display()
  {
    display2();
  }
}
class Rectangle
{
  // Tile coordinates of the Rectangle's top-left corner.
  int xt, yt;
  
  // Tile coordinates of the initial Tile found in Rectangle generation.
  int xt0, yt0;
  
  // Rectangle width right and left of (xt0,yt0).
  int wright, wleft;
  
  // Rectangle height up and down from (xt0,yt0).
  int hup, hdown;
  
  int w; // width
  int h; // height
  
  // Area of this Rectangle.
  int area;
  
  // Initialized to false, becomes true when the rectangle cannot grow further in the given direction.
  boolean stoppedUp, stoppedRight, stoppedDown, stoppedLeft;
  
  // When true, the Rectangle's initial Tile is contained in a rectangular patch of Tiles
  // large enough for inclusion in the parent Room.
  boolean bigEnough;
  
  // Room this Rectangle is contained in.
  Room parentRoom;
  
  /////////////////////////////////////////////////////////////////////////
  Rectangle(Room parentRoom_, int xt0_, int yt0_, int minDimension1, int minDimension2)
  {
    // Constructor with input (xt0_, yt0_)
    
    parentRoom = parentRoom_;
    
    xt0 = xt0_;
    yt0 = yt0_;
   
    wleft = 0;
    wright = 0;
    hup = 0;
    hdown = 0;
    
    stoppedUp = false;
    stoppedRight = false;
    stoppedDown = false;
    stoppedLeft = false;
    bigEnough = false;
    
    if(grow(minDimension1, minDimension2)) 
    {
      // Tile (xt0,yt0) is contained in a new Rectangle of size bigger than
      // minDimension1 x minDimension2. Triggers the addition of this Rectangle
      // to Room parentRoom.
      bigEnough = true;
    }
  }
  
  
  Rectangle(Room parentRoom_, Tile tile_, int minDimension1, int minDimension2)
  {
    // Constructor with a Tile
    
    bigEnough = false;
    
    if(tile_.type != T_WALL)
    {
      parentRoom = parentRoom_;
      
      xt0 = tile_.xt;
      yt0 = tile_.yt;
     
      wleft = 0;
      wright = 0;
      hup = 0;
      hdown = 0;
      
      stoppedUp = false;
      stoppedRight = false;
      stoppedDown = false;
      stoppedLeft = false;
      
      
      if(grow(minDimension1, minDimension2)) 
      {
        // Tile (xt0,yt0) is contained in a new Rectangle of size bigger than
        // minDimension1 x minDimension2. Triggers the addition of this Rectangle
        // to Room parentRoom.
        bigEnough = true;
      }
    }
  }
  
  /////////////////////////////////////////////////////////////////////////
  public boolean grow(int minDimension1, int minDimension2)
  {
    while(!stoppedUp || !stoppedRight || !stoppedDown || !stoppedLeft)
    {
      if (!stoppedRight)
      {
        stoppedRight = growRight();
      }
      
      if (!stoppedDown)
      {
        stoppedDown = growDown();
      }
      
      if (!stoppedLeft)
      {
        stoppedLeft = growLeft();
      }
      
      if (!stoppedUp)
      {
        stoppedUp = growUp();
      }
    }
    
    xt = xt0 - wleft;
    yt = yt0 - hup;
    w = wleft + wright + 1; // +1 for (xt0,yt0).
    h = hup + hdown + 1; // +1 for (xt0,yt0).
    
    area = w * h;
    
    if( (w >= minDimension1 && h >= minDimension2) || (w >= minDimension2 && h >= minDimension1) )
    {
      // Rectangle is large enough to keep as part of the Room.
      return true;
    }
    else
    {
      return false;
    }
  }
  
  /////////////////////////////////////////////////////////////////////////
  public boolean growUp()
  {
    // Checks to see whether the Rectangle has room to grow up one row.
    
    int checky = yt0 - hup - 1;
    
    for(int checkx = xt0 - wleft; checkx <= xt0 + wright; checkx++)
    {
      Tile theTile = tiles[checkx][checky];
      if(theTile.yt == 0 || theTile.type == T_WALL || theTile.roomState == R_YES)
      {
        // Next row of Tiles up contains a wall Tile or already belongs to an existing Room.
        
        // true as in 'it is true that growth upward is stopped'.
        return true;
      }
    }
    
    hup += 1; // grow up.
    
    return false;
  }
  
  ///////////////////////////////////////////////////////////////////////////
  public boolean growRight()
  {
    // Checks to see whether the Rectangle has room to grow right one column.
    
    int checkx = xt0 + wright + 1;
    
    for(int checky = yt0 - hup; checky <= yt0 + hdown; checky++)
    {
      Tile theTile = tiles[checkx][checky];
      if(theTile.xt == tilesX - 1 || theTile.type == T_WALL || theTile.roomState == R_YES)
      {
        // Next column of Tiles right contains a wall Tile or already belongs to an existing Room.
        
        // true as in 'it is true that growth rightward is stopped'.
        return true;
      }
    }
    
    wright += 1; // grow right.
    
    return false;
  }
  
  ///////////////////////////////////////////////////////////////////////////
  public boolean growDown()
  {
    // Checks to see whether the Rectangle has room to grow down one row.
    
    int checky = yt0 + hdown + 1;
    
    for(int checkx = xt0 - wleft; checkx <= xt0 + wright; checkx++)
    {
      Tile theTile = tiles[checkx][checky];
      if(theTile.yt == tilesY - 1 || theTile.type == T_WALL || theTile.roomState == R_YES)
      {
        // Next row of Tiles down contains a wall Tile or already belongs to an existing Room.
        
        // true as in 'it is true that growth downward is stopped'.
        return true;
      }
    }
    
    hdown += 1; // grow down.
    
    return false;
  }
  
  ////////////////////////////////////////////////////////////////////////////
  public boolean growLeft()
  {
    // Checks to see whether the Rectangle has room to grow left one column.
    
    int checkx = xt0 - wleft - 1;
    
    for(int checky = yt0 - hup; checky <= yt0 + hdown; checky++)
    {
      Tile theTile = tiles[checkx][checky];
      if(theTile.xt == 0 || theTile.type == T_WALL || theTile.roomState == R_YES)
      {
        // Next column of Tiles left contains a wall Tile or already belongs to an existing Room.
        
        // true as in 'it is true that growth leftward is stopped'.
        return true;
      }
    }
    
    wleft += 1; // grow left.
    
    return false;
  }
  
  /////////////////////////////////////////////////////////////////////////
  public void addBoundaryTiles()
  {
    // Add all Tiles bordering this Rectangle, not already in a Room or Room's tileCheckList,
    // to this Tile's Room's tileCheckList.
    
    // Add the Tiles above and below the Rectangle
    for(int x = xt; x < xt + w; x++)
    {
      // above
      if(yt > 1) // Don't add World boundary Tiles.
      {
        tile2boundary(tiles[x][yt-1]);
      }
       
      //below
      if(yt + h < tilesY - 1) // Don't add World boundary Tiles.
      {
        tile2boundary(tiles[x][yt+h]);
      }
    }
    
    // Add the Tiles to the left and right of the Rectangle.
    for(int y = yt; y < yt+h; y++)
    {
      // left
      if(xt > 1) // Don't add World boundary Tiles.
      {
        tile2boundary(tiles[xt-1][y]);
      }
      
      // right
      if (xt + w < tilesX - 1) // Don't add World boundary Tiles.
      {
        tile2boundary(tiles[xt+w][y]);
      }    
    }
  }
  
  ///////////////////////////////////////////////////////////////////////////
  public void updateTiles()
  {
    for(int x = xt; x < xt + w; x++)
    {
      for(int y = yt; y < yt + h; y++)
      {
        tiles[x][y].roomState = R_YES;
        tiles[x][y].parentRoom = parentRoom;
        tiles[x][y].c_hroom = parentRoom.c_h;
      }
    }
  }
  
  ////////////////////////////////////////////////////////////////////////////
  public void tile2boundary(Tile aTile)
  {
    // Adds input Tile aTile to this Rectangle's Room's tileCheckList.
    
    if( (aTile.type != T_WALL) && (aTile.roomState == R_NO) )
    {
      // Add aTile to the list of new Tiles to check for Rooms if it's not
      // a wall Tile and not already in a Room.
      parentRoom.tileCheckList.add(aTile);
      aTile.roomState = R_BDRY;
    }
  }
  
}
class Room
{
  
  // ArrayList of all Tiles in the Room.
  ArrayList<Tile> tileList; 
  
  // ArrayList of all Tiles adjacent to the Room to be checked for Rectangles.
  ArrayList<Tile> tileCheckList; 
  
  // A Room is subdivided into adjacent nonintersecting Rectangles.
  ArrayList<Rectangle> rectList;
  
  // Tile coordinate of the initial Tile which generates the Room.
  int x0t, y0t;
  
  // Area occupied by the Room.
  int area;
  
  // All effects modulated by Room area.
//  color c_base; // Base color effect created by the Room.
  float c_h; // Base hue effect created by the Room.
  float c_s; // Base saturation effect created by the Room.
  float c_b; // Base brightness effect created by the Room.
  
  // Used in Room setup, initializes to true. If the Room is large enough
  // (according to some parameters input to the constructor), changes to false.
  boolean empty;  
  
  //////////////////////////////////////////////////////////////////////////////////
  Room(Tile tile_, int minDimension1, int minDimension2)
  {
    empty = true;
    
    if(tile_.roomState == R_NO)
    {
      // Only bother creating a Room if tile_ is not already in one or known to not be contained
      // in a room. 
      
      tileList = new ArrayList<Tile>();
      tileCheckList = new ArrayList<Tile>();
      rectList = new ArrayList<Rectangle>();
      
      x0t = tile_.xt;
      y0t = tile_.yt;
      
      area = 0;
      
      //c_base = color(0.2, -0.02, 0.02);
      c_h = random(-0.5f, 0.5f);//0.2;
      c_s = -0.02f;
      c_b = 0.02f;
      
      // begin the Room creation procedure.
      // Create a new Room by adding a Rectangle starting at tile_ if it
      // is big enough, then all neighboring Rectangles recursively.
      tileCheckList.add(tile_);
      while(tileCheckList.size() > 0)
      {
        Tile aTile = tileCheckList.get(0);
        tileCheckList.remove(0);
        Rectangle newRect = new Rectangle(this, aTile, minDimension1, minDimension2); 
        if(newRect.bigEnough)
        {
          empty = false;
          addRectangle(newRect);
        }
        else
        {
          aTile.roomState = R_CHKD;
        }
      }
    }
  }
  
  //////////////////////////////////////////////////////////////////////////////////
  public void addRectangle(Rectangle rect_)
  {
    // Add rect_ to rectList and add its area to the Room's area.
    rectList.add(rect_);
    area += rect_.area;
    
    // Set rect_'s Tiles' roomState to R_YES and set parentRoom.
    rect_.updateTiles();
    
    // Add the appropriate boundary Tiles to tileCheckList.
    rect_.addBoundaryTiles();
  }
  
}
// This file uses the following global variables defined in maze2:
//   TILE_SIZE

// Mnemonic variable names for the Tile types.
final int T_WALL = 0;
final int T_PATH = 1;
final int T_WIN  = 2;

// Mnemonic variable names for a Tile's Room states.
final int R_NO = 0;
final int R_BDRY = 1;
final int R_YES = 2;
final int R_CHKD = 3; // has been in a checklist, known to not be contained in a Room.

class Tile
{
  // (x,y) Tile coordinates of this Tile
  int xt;
  int yt;
  
  // (x,y) World coordinates of the top-left corner of this Tile. (0,0) is the top-left pixel of the maze.
  int xw;
  int yw;
  
  int type; // Type of Tile. Initializes to 0.
  // Types currently defined:
  //    0: wall Tile (never walkable).
  //    1: walkable Tile.
  //    2: winning Tile.
  
  boolean blocked; // If true, the Tile cannot be traversed.
  
  //int numNeighbors; // Number of Tiles which this Tile borders.
  ArrayList<Tile> neighborList; // ArrayList pointing to the walkable neighbor Tiles. 
  
  // Diffusion calculations look like my.z = sum_{neighbors}[neighborWeight * neighbor.z] - my.z.
  // Diagonal neighbors have weight baseNeighborWeight. URDL neighbors have weight sqrt(2) * baseNeighborWeight.
  float baseNeighborWeight; 

  float c_h, c_s; // HS (of HSB) values in range [0,1]. Base Tile color.
  float final_h; // Final rendered hue value
  float c_bmax = 1; // Maximum Tile brightness
  float c_bbase, c_bactive; // B has passive and active illumination components.
  float c_bactiveNew; // Used in updating c_bactive.
  float a_h, a_s, a_b; // HSB values in range [0,1]. Alignment Tile color modifier (additive).
  float final_b;
  float sparkle; 
  
  float dh; // Amount that ch changes each frame (for color-changing effects).
  
  // The initial value of desat controls when saturation starts: smaller values shift the start time outward. 
  // The effect is logarithmic: each power of 10 shifts the effect onset later by ~6 seconds.
  float desat; 
  float desatRate; // Rate at which desaturation occurs
  
  boolean initialized; // Starts false, changes to true once this Tile has been initialized by the maze initialization routine.
  //boolean inInitializationList; // Starts false, changes to true when the Tile is in the list of Tiles to be initialized.
 
  ArrayList<Item> itemList; // List of all Items whose position overlaps this Tile.
  ArrayList<Entity> entityList; // List of all Entities whose position overlaps this Tile.
  
  // Value in [-1,1], indicating disposition to spawn friendly vs. hostile Entities.
  float alignment;
  
  // If 0, Tile is not in a room (R_NO). 
  // If 1, Tile is in a Room's boundary Tile check list (R_BDRY). 
  // If 2, Tile is in a Room (R_YES).
  // If 3, Tile has been through a Room's tileCheckList and found to be contained in no Room (R_CHKD).
  char roomState;
  
  // If in a Room, this points to it
  Room parentRoom;
  float c_hroom;
  
  /////////////////////////////////////////////////////////////////////////////////
  Tile(int xt_, int yt_)
  {
    xt = xt_;
    yt = yt_;
    
    xw = xt * TILE_SIZE;
    yw = yt * TILE_SIZE;
    
    //numNeighbors = 0;
    neighborList = new ArrayList<Tile>(8);
    
    // Initializes to wall type.
    setType(T_WALL);
    
    initialized = false;
    //
    
    itemList = new ArrayList<Item>();
    entityList = new ArrayList<Entity>();
    
    alignment = 0;
    //c_alignment = color(0.1, 0., 0.05);
    a_h = 0.1f;
    a_s = 0.f;
    a_b = 0.05f; 
    
    c_bactive = 0.f;
    c_bactiveNew = 0.f;
    
    desat = 0;
    desatRate = 0.000025f;
    
    roomState = R_NO;
    c_hroom = 0;
  }
  
  ///////////////////////////////////////////////////////////////////////////////////
  public void display()
  {    
    //noStroke();
    pushMatrix();
    translate(-screenX, -screenY);
    
    int numWinSubdivisions = 4;
    int subdivisionSize = TILE_SIZE / numWinSubdivisions;
    
    // Fill colors.
    if(type == 2) // winning Tile
    {
      noStroke();
      for(int i = 0; i < numWinSubdivisions; i++) {
        for(int j = 0; j < numWinSubdivisions; j++) {
          c_h = random(1);
          dh = constrain(dh + 0.005f * random(-1,1), -1, 1);
          if(player.ghost && type != T_WALL)
          {
            final_b = 0.9f;
          }
          else
          {
            final_b = constrain(c_bbase + c_bactive + a_b * alignment, 0, 1);
          }
          fill(c_h, 1, final_b);
          rect(xw + i * subdivisionSize, yw + j * subdivisionSize, subdivisionSize, subdivisionSize);
        }
      }
    }
    else
    {
      float actual_final_h = mod1(final_h + 0.3f * sparkle * sin(0.25f * (1 + sparkle) * t));
      
      float final_s = constrain(c_s - desat + a_s * alignment, 0, 1);
      //float s_factor = sign2(final_s - 0.1);
      //final_s = constrain(final_s - s_factor * heartbeat(t, sparkle, 0.1), 0, 1);
      
      // When the player is a ghost, display all path Tiles
      if(player.ghost && type != T_WALL)
      {
        final_b = 0.9f;
      }
      else
      {
        final_b = constrain(c_bbase + c_bactive + a_b * alignment, 0, 1);
        //final_b = sigmoid(c_bbase + c_bactive + a_b * alignment);
      }
      
      fill(actual_final_h , final_s, final_b * c_bmax);
      noStroke();
      
      // Draw the rectangle
      rect(xw, yw, TILE_SIZE, TILE_SIZE);
    }
    
    
    
    popMatrix();
    
    if (itemList.size() > 0) {
      for (int i = 0; i < itemList.size(); i++) {
        itemList.get(i).display();
        
      }
    }
    
  }
  
  //////////////////////////////////////////////////////////////////////////////////
  public void setType(int type_)
  {
    type = type_;
    
    // Also, special changes for each type (blocked -> unblocked, etc.)
    // on a case-by-case basis.
    switch(type_)
    {
      case 0: // Wall
        blocked = true;
        c_h = 0;
        c_s = 1;
        c_bmax = 1;
        c_bbase = 0.0f;
        break;
        
      case 1: // Path
        blocked = false;
        c_h = 0.635f;
        c_s = 0.5f;
        c_bmax = 1;
        c_bbase = 0;
        break;
        
      case 2: // Winning
        blocked = false;
        c_h = 0.4f; // whatever, it drifts
        c_s = 1;
        c_bmax = 1;
        c_bbase = 0;
        break;
    }
  }
  
}
// base class for ArrayLists of Tiles to be used in the following way:
// (1) an update function is run on each Tile in TileList, every k frames,
//     where k is specified on construction.
// (2) the update function will modify one or more properties of each Tile
//     and also add additional Tiles to the TileList (i.e. the Tile's neighbors).

class TileList
{
  // Contains all Tiles in the List.
  ArrayList<Tile> theList;
  
  // A boolean vector of length (tilesX*tilesY), 
  // intializes to false and becomes true when a Tile is added.
  // Indexed from the top-left corner of the World and runs horizontally.
  boolean[] inTheList;
  
  ////////////////////////////////////////////////////////////////////////////////////////
  TileList()
  {
    theList = new ArrayList<Tile>();
    inTheList = new boolean[tilesX*tilesY];
  }
  
  /////////////////////////////////////////////////////////////////////////////////////////
  public void updateAll()
  {
    if(theList.size() > 0)
    {
      for(int i = theList.size()-1; i>=0; i--)
      {
        // Call the Tile update function on each Tile in theList.
        //Tile aTile = theList.get(i);
        update(i);
      }
    }
  }
  
  //////////////////////////////////////////////////////////////////////////////////////////
  public boolean tileRemovalCheck(Tile tile_)
  {
    // This method is overwritten by subclasses. Default behavior is to always
    // return true.
    return true;
  }
  
  //////////////////////////////////////////////////////////////////////////////////////////
  public void update(int listIdx_)
  {
    // Overwritten by subclasses.
  }
  
  ///////////////////////////////////////////////////////////////////////////////////////////
  public Tile pop(int listIdx_)
  {
    Tile aTile = theList.get(listIdx_);
    theList.remove(listIdx_);
    return aTile;
  }
  
  ///////////////////////////////////////////////////////////////////////////////////////////
  public void addTile(Tile tile_)
  {
    // Adds the Tile tile_ to theList if it's not in 
    // there already. Updates inTheList as well.
    
    int tileIdx = getTileIdx(tile_);
    
    if(!inTheList[tileIdx])
    {
      theList.add(tile_);
      inTheList[tileIdx] = true;
    }
  }
  
  ////////////////////////////////////////////////////////////////////////////////////////////
  public void removeTile(int listIdx_)
  {
    // Removes theList[listIdx_] from theList.
    // Updates inTheList as well.
    
    Tile aTile = theList.get(listIdx_);
    
    int tileIdx = getTileIdx(aTile);
    
    theList.remove(listIdx_);
    inTheList[tileIdx] = false;
  }    
}

// ******************************************************
// ******************************************************
class LightList extends TileList
{
  // Diffusion-based lighting effect. Modifies the c_bactive property of Tiles.
  
  // diffusion rate.
  //float diffusionRate = 0.2;
  
  // decay constant.
  float decayRate = 0.95f;//0.99999;
  
  // c_bactive threshold for inclusion in the List.
  float threshold = 0.0001f;//0.00001;
  
  /////////////////////////////////////////////////////////////////////////////////////////////
  LightList()
  {
    super();
  }
  
  /////////////////////////////////////////////////////////////////////////////////////////////  
  public void updateAll(float diffusionRate_)
  {
    // Add the Tile that the player is standing on to the LightList.
    //addTile(tiles[player.xtcenter][player.ytcenter]);
    
    for(int i = theList.size()-1; i>=0; i--)
    {
      // Call the Tile update function on each Tile in theList.
      //Tile aTile = theList.get(i);
      update(i, diffusionRate_);
    }
  }
  
  ///////////////////////////////////////////////////////////////////////////////////////////////
  public void update(int listIdx_, float diffusionRate_)
  {
    Tile aTile = theList.get(listIdx_);
    
    float chargeStrength = 0.1f + 0.9f * max(0, (player.glowActive - player.glow) / player.glow);
    
    aTile.c_bactive = decayRate * aTile.c_bactiveNew;
    
    aTile.desat = aTile.desat + pow(constrain(aTile.c_bactive, 0, 1), 2) * aTile.desatRate * chargeStrength * (1 - aTile.desat);
    
    if(tileRemovalCheck(aTile))
    {
      removeTile(listIdx_);
    }
    else
    {
      // Reset the active component update.
      aTile.c_bactiveNew = 0;
      
      // Diffuse aTile's c_bactive to its neighbors, add
      // those neighbors to theList.
      diffuseLight(aTile, diffusionRate_);     
    }
    
  }
  
  /////////////////////////////////////////////////////////////////////////////////////////////////
  public void diffuseLight(Tile tile_, float diffusionRate_)
  {
    // Iterate through tile_'s neighborList, diffusing and adding neighbors to 
    // theList.

    for(int i = 0; i < tile_.neighborList.size(); i++)
    {
      Tile neighbor = tile_.neighborList.get(i);
      
      // Add a portion of tile_.c_bactive to URDL neighbors
      if(abs(tile_.xt - neighbor.xt) + abs(tile_.yt - neighbor.yt) == 2)
      {
        // Diagonal neighbor. Weight diffusion term by baseNeighborWeight.
        neighbor.c_bactiveNew += diffusionRate_ * tile_.baseNeighborWeight * tile_.c_bactive;
      }
      else
      {
        // URDL neighbor. Weight diffusion term by sqrt(2) * baseNeighborWeight
        neighbor.c_bactiveNew += diffusionRate_ * SQRT2 * tile_.baseNeighborWeight * tile_.c_bactive;
      }
      
      // Add Tile neighbor to LightList's theList.
      addTile(neighbor);
    }
    
    // Add a portion of tile_.c_bactive to tile_.c_bactiveNew
    tile_.c_bactiveNew += (1 - diffusionRate_) * tile_.c_bactive;
  }
  
  //////////////////////////////////////////////////////////////////////////////////////////////////
  public boolean tileRemovalCheck(Tile tile_)
  {
    if(tile_.c_bactive < threshold)
    {
      return true;
    }
    return false;
  }
      
}


// *********************************************
// *********************************************
class InitializationList extends TileList
{
  
  // Changes to true when tiles[xtwin][ytwin] is added to the InitializationList.
  // Signals successful maze setup (a path exists from start to finish).
  boolean foundTheWinner = false;
  
  //////////////////////////////////////////////////////////////////////////////////////////////////  
  InitializationList()
  {
    super();
    
    // Add the starting Tile to the InitializationList.
    addTile(tiles[xtstart][ytstart]);
    tiles[xtstart][ytstart].c_h = random(0, 1);
    tiles[xtstart][ytstart].dh = random(-1, 1);
  }
  
  //////////////////////////////////////////////////////////////////////////////////////////////////
  public boolean update()
  {
    // Changes to true when tiles[xtwin][ytwin] is added to the InitializationList.
    // Signals successful maze setup (a path exists from start to finish).
    // boolean foundTheWinner = false;
    
    // The constructor adds a single path Tile to theList. Each iteration of update()
    // removes a single Tile from theList, intializes it, and then adds any unitialized 
    // path Tile neighbors to theList.
    while(theList.size() > 0)
    {
      Tile aTile = pop(0);
      initialize(aTile);      
    }   
 
    return foundTheWinner;   
  }
  
  ///////////////////////////////////////////////////////////////////////////////////////////////////
  public void initialize(Tile tile_)
  {
    tile_.initialized = true;
    
    int xti = tile_.xt;
    int yti = tile_.yt;
    
    // Check if tile_ is the winning Tile.
    if(xti == xtwin && yti == ytwin)
    {      
      // Set tile_'s type to T_WIN.
      tile_.setType(T_WIN);
      
      // Confirm that we've found the winner.
      foundTheWinner = true;
    }

    // Add neighboring non-wall Tiles to tile_.neighborList, and add any non-initialized
    // neighboring Tiles to theList.
    addTileNeighbors(tile_);
    
    float itemCheck = random(1);
    if (itemCheck < 1 * baseItemProbability) {
      ItemChargeRestore aItem = new ItemChargeRestore(tile_.xt, tile_.yt);
    } else if (itemCheck < 2 * baseItemProbability) {
      ItemGlowBoost aItem = new ItemGlowBoost(tile_.xt, tile_.yt);
    } else if (itemCheck < 3 * baseItemProbability) {
      ItemChargeBoost aItem = new ItemChargeBoost(tile_.xt, tile_.yt);
    } else if (itemCheck < 4 * baseItemProbability) {
      ItemStaminaBoost aItem = new ItemStaminaBoost(tile_.xt, tile_.yt);
    }
    //} else if(itemCheck < 0.04) {
    //  ItemStaminaBoost aItem = new ItemStaminaBoost(tile_.xt, tile_.yt);
    //}
    
    // Add a Torch with some probability.
    //float torchCheck = random(1);
    //if(torchCheck < 0.005)
    //{
    //  Torch aTorch = new Torch(tile_.xw + TILE_SIZE/2, tile_.yw + TILE_SIZE/2, 1);
    //}
    
  }
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////
  public void addTileNeighbors(Tile tile_)
  {
    int xti = tile_.xt;
    int yti = tile_.yt;
    
    int numDiagonalNeighbors = 0;
    int numURDLNeighbors = 0;
    
    // Add neighboring path Tiles to tile_.neighborList and theList.
    for(int dx = -1; dx < 2; dx++)
    {
      if(xti + dx >= 0 && xti + dx < tilesX)
      {
        for(int dy = -1; dy < 2; dy++)
        {
          if(yti + dy >=0 && yti + dy < tilesY)
          {
            if(!(dy == 0 && dx == 0)) // don't check yourself!
            {
              // A neighboring Tile to tile_.
              Tile nTile = tiles[xti + dx][yti + dy];
              
              // Add this neighbor if it's not a wall.
              if(!(nTile.type == T_WALL))
              {
                
                // Rules for adding diagonal neighbors.
                if(dx != 0 && dy != 0)
                {
                  // Only add diagonally-neighboring path Tiles if both non-diagonal
                  // neighbors are path Tiles.
                  if(!(tiles[xti+dx][yti].type == T_WALL) && !(tiles[xti][yti+dy].type == T_WALL))
                  {
                    tile_.neighborList.add(nTile);
                    numDiagonalNeighbors += 1;
                    
                  }
                }    
                // Add URDL neighbors        
                else 
                {
                  tile_.neighborList.add(nTile);
                  numURDLNeighbors += 1;
                }
                
                // Add nTile to theList if not initialized or inTheList.
                if(!(nTile.initialized))
                {
                  // addTile() checks to see whether nTile is inTheList.
                  addTile(nTile);
                  nTile.dh = constrain(tile_.dh + d2hRate * random(-1, 1), -1, 1);
                  nTile.c_h = mod1(tile_.c_h + dhRate * nTile.dh);
                  float distToWinner = pow(nTile.xt - xtwin, 2) + pow(nTile.yt - ytwin, 2);
                  float distScale = max(0, (maxDistance - distToWinner) / maxDistance);
                  nTile.sparkle = pow(distScale, 1);
                  
                  
                  nTile.final_h = nTile.c_h;
                  //nTile.final_h = hScale * nTile.c_h + (1 - hScale) * baseHue;
                }
              }
            }
          }
        }
      }
    }
    
    // Calculate baseNeighborWeight (used for lighting).
    tile_.baseNeighborWeight = 1.f/(numDiagonalNeighbors + SQRT2 * numURDLNeighbors);
  }
  
}
// Mnemonic variable names for World states.
final int W_PAUSE = 0;
final int W_PLAY = 1;
final int W_WIN = 2;

// *******************************************************
// *******************************************************
class World
{
  // Initializes the Arrays 'chunks' and 'tiles', provides an interface
  // to quickly manipulate these Arrays.
  
  // A Plan to create the maze.
  Plan mazeSetupPlan;
  
  // Maze RNG seed
  int seed;
  
  // Tiles in the World can be sent through initList for some property
  // initializations.
  InitializationList initList;
  
  // Possible states: W_PAUSE, W_PLAY, W_WIN. Controls which World
  // updates happen each frame.
  int state;
  
  ArrayList<Room> rooms;
  int roomMinDimension1 = 4;
  int roomMinDimension2 = 4;
  
  // Update all Chunks within chunkUpdateRadius of the player (in Chunk coordinates).
  int chunkUpdateRadius = 2;
  
  // Number of (non-Player) existing Entity types.
  int numEntityTypes = 1;
  
  // Number of existing Item types.
  int numItemTypes = 0;
  
  // Base light diffusion rate
  float diffusionRateMin = 0.25f;
  float diffusionRateMax = 1;
  float diffusionRate = diffusionRateMin;
  float dDiffusion = 0.1f;
  
  //////////////////////////////////////////////////////////////////////////////////////////////////
  World(Plan mazeSetupPlan_, int seed_)
  {
    seed = seed_;
    // Initialize chunks
    chunks = new Chunk[CHUNKSX][CHUNKSY];
    for(int i = 0; i < CHUNKSX; i++)
    {
      for(int j = 0; j < CHUNKSY; j++)
      {
        chunks[i][j] = new Chunk(i,j);
      }
    }
    
    // Initialize tiles
    tiles = new Tile[tilesX][tilesY];
    for(int i = 0; i < tilesX; i++)
    {
      for(int j = 0; j < tilesY; j++)
      {
        tiles[i][j] = new Tile(i,j);
      }
    }
    
    mazeSetupPlan = mazeSetupPlan_;
    
    initList = new InitializationList();
    
    // Try to create a maze.
    if(!createMaze())
    {
      println("Maze creation failed.");
      exit();
    }
    
    setupRooms();
    
    takeMazeShot();
    
    state = W_PLAY;
    
  }
  
  ////////////////////////////////////////////////////////////////////////////////////////////////
//  void addEntity(int ID_, float x_, float y_)
//  {
//    switch(ID_)
//    {
//      case 0:
//        Torch newEntity = new Torch(
  
  ////////////////////////////////////////////////////////////////////////////////////////////////
  public boolean createMaze()
  {
    // Attempts to create a solvable maze using mazeSetupPlan. If a solvable maze is generated
    // before maxAttempts is reached, returns true. Else, returns false.
    
    int creationAttemptCounter = -1;
    int maxAttempts = 1000;
    
    boolean creationSuccessful = false;
    
    while((!initList.foundTheWinner) && creationAttemptCounter < maxAttempts)
    {
      clear();
      creationAttemptCounter += 1;
      mazeSetupPlan.run(seed + creationAttemptCounter);
      initList.update();    
    }
    
    if(initList.foundTheWinner)
    {
      creationSuccessful = true;
    }
    
    return creationSuccessful;
  }
  
  //////////////////////////////////////////////////////////////////////////////////////////////////
  public void update()
  {
    t += dt;

    if (state == W_PLAY) {
      // Update Chunks within chunkUpdateRadius of the player.
      int imin = max(0, player.xc - chunkUpdateRadius);
      int imax = min(CHUNKSX - 1, player.xc + chunkUpdateRadius);
      
      int jmin = max(0, player.yc - chunkUpdateRadius);
      int jmax = min(CHUNKSY - 1, player.yc + chunkUpdateRadius);
        for(int i = imin; i <= imax; i++) {
          for(int j = jmin; j <= jmax; j++) {
            chunks[i][j].updateEntities();
          }
        }
      
      if (mousePressed && player.charge > player.minCharge) {      
        diffusionRate = constrain((1 + dDiffusion) * diffusionRate, diffusionRateMin, diffusionRateMax);
      } else {
        diffusionRate = constrain((1 - 0.2f * dDiffusion) * diffusionRate, diffusionRateMin, diffusionRateMax); 
      }
    }
       
    // Update lightList
    lightList.updateAll(diffusionRate);
  }
  
  //////////////////////////////////////////////////////////////////////////////////////////////////
  public void display()
  {
    screenX = constrain(player.x - width / 2, 0, maxScreenX);
    screenY = constrain(player.y - height / 2, 0, maxScreenY);
    
    int drawStartTileX = PApplet.parseInt(screenX / TILE_SIZE);
    int drawStartTileY = PApplet.parseInt(screenY / TILE_SIZE);
    
    texture(tileSheet1);
    
    // Draw on-screen Tiles
    for(int i = 0; i < tilesOnScreenX; i++)
    {
      int nextX = min(drawStartTileX + i, tilesX - 1);
      
      for(int j = 0; j < tilesOnScreenY; j++)
      {
        int nextY = min(drawStartTileY + j, tilesY - 1);
        Tile nextTile = tiles[nextX][nextY];
        if(nextTile.type != T_WALL) {
          tiles[nextX][nextY].display();
        }
      }
    }
    
    // Draw Entities.
    int imin = max(0, player.xc - chunkDrawRadiusX);
    int imax = min(CHUNKSX - 1, player.xc + chunkDrawRadiusX);
    
    int jmin = max(0, player.yc - chunkDrawRadiusY);
    int jmax = min(CHUNKSY - 1, player.yc + chunkDrawRadiusY);
    
    for(int i = imin; i <= imax; i++)
    {
      for(int j = jmin; j <= jmax; j++)
      {
        chunks[i][j].drawEntities();
      }
    }
  }
  
  //////////////////////////////////////////////////////////////////////////////////////////////////
  public void wipeInitialized()
  {
    // Sets properties 'initialized' and 'inInitializationList' to 
    // false for all Tiles in tiles.
    for(int i = 0; i < tilesX; i++)
    {
      for(int j = 0; j < tilesY; j++)
      {
        tiles[i][j].initialized = false;
        //tiles[i][j].inInitializationList = false;
      }
    }
  }  
  
  ////////////////////////////////////////////////////////////////////////////////////////////////////
  public void setupRooms()
  {
    rooms = new ArrayList<Room>();
    
    for(int x = 1; x < tilesX - 1; x++)
    {
      for(int y = 1; y < tilesY - 1; y++)
      {
        Room aRoom = new Room(tiles[x][y], roomMinDimension1, roomMinDimension2);
        if(!aRoom.empty)
        {
          // If nonempty, add aRoom to rooms.
          rooms.add(aRoom);
        }
      }
    }
  }
        
        
}
//////////////////////////////////////////////////////////////////////////////////////////////
public float mod1(float x_)
{
  // Does a proper x mod 1 operation, so that negative numbers become positive
  
  if(x_ < 0)
  {
    return x_ % 1.0f + 1;
  }
  else
  {
    return x_ % 1.0f;
  }
}


///////////////////////////////////////////////////////////////////////////////////////////////
public int sign(float x_)
{
  // Returns -1 if xin < 0, 0 if xin == 0, +1 if xin > 0
  
  if(x_ < 0)
  {
    return -1;
  }
  else if(x_ == 0)
  {
    return 0;
  }
  else if(x_ > 0)
  {
    return 1;
  }
  else
  {
    return -2; // How did you get here?
  }
}

///////////////////////////////////////////////////////////////////////////////////////////////
public int sign2(float x_)
{
  // Returns -1 if xin < 0, +1 if xin >= 0
  
  if(x_ < 0)
  {
    return -1;
  }
  else if(x_ >= 0)
  {
    return 1;
  }
  else
  {
    return -2; // How did you get here?
  }
}

////////////////////////////////////////////////////////////////////////////////////////////////
public int getTileIdx(Tile tile_)
{
  // Returns the index of tile_ in a linear indexing of the World
  // which starts at 0 at the top-left corner and runs horizontally
  // then downward.
  
  return tile_.yt * tilesX + tile_.xt;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
public float sigmoid(float x_)
{
  return 1.f/(1+exp(4.8f - 8 * x_));
}


public float heartbeat(float t_, float strength_, float timeScale_) {
  
  
  float bpm = 20 + strength_ * strength_ * 120;
  float beat2Strength = 0.65f + 0.35f * strength_ * strength_;
  float beat1T = 0.15f;
  float beat2T = 0.25f;
  float beat1Bandwidth = 0.0015f;
  float beat2Bandwidth = 0.0045f;
  
  float timeScale = timeScale_ * bpm / 60;
  
  float T = (timeScale * t_) % 1;
  
  
  return pow(strength_, 1.25f) * (exp(-pow(T - beat1T, 2) / beat1Bandwidth) + beat2Strength * exp(-pow(T - beat2T, 2) / beat2Bandwidth));
  
}

/////////////////////////////////////////////////////////////////////////////////////////////////
public void takeMazeShot()
{
  int tsize = 4;
    PImage mazeShot = createImage(tsize*tilesX, tsize*tilesY, RGB);
    for(int i=0; i<tilesX; i++)
    {
      int x0 = i * tsize;
      for(int j=0; j<tilesY; j++)
      {
        int y0 = j * tsize;
        Tile ti = tiles[i][j];
        int tileColor;
        if(ti.initialized)
        {
          tileColor = color(ti.final_h, 1, 1);
        }
        else
        {
          tileColor = color(0,0,0.2f);
        }
        
        for(int k=0; k<tsize; k++)
        {
          for(int l=0; l<tsize; l++)
          {
            if(ti.type == T_WIN)
            {
              mazeShot.set(x0+k,y0+l, color(random(1), 1, 1));
            }
            else
            {
              mazeShot.set(x0+k,y0+l, tileColor);
            }
          }
        }
      }
    }
    
    int mnth = month();
    int dy = day();
    int hr = hour();
    int mn = minute();
    int sec = second();
    
    String fname = "images/mazeshot" + nf(mnth, 2) + '_' +  nf(dy, 2) + '_' +nf(hr, 2) + nf(mn, 2) + nf(sec, 2) + ".png";
    
    mazeShot.save(fname);
}
boolean shiftPressed;

public void keyPressed()
{
  // key press callback function.
  
  if(key != CODED && key < numKeys)
  {
    keyList[key] = true;
  } else if(key == CODED && keyCode == SHIFT) {
    shiftPressed = true;  
  }
  
}

public void keyReleased()
{
  // key release callback function.
  
  if(key != CODED && key < numKeys)
  {
    keyList[key] = false;
    keyPressedList[key] = false;
  } else if(key == CODED && keyCode == SHIFT) {
    shiftPressed = false;  
  }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
public void keyCheck()
{
  // Quit check.
  if(keyList['q'] || keyList['Q']) {
    exit();
  }
  
  // Check WASD keys for Player movement.
  checkMovement();
  
  // Toggle Player ghost mode
  if(debugMode && (keyList['g'] || keyList['G']) && !keyPressedList['g']) {
    player.ghost = !player.ghost;
    keyPressedList['g'] = true;
  }
  
  // Print the number of path Tiles in tiles
  if(keyList['p'] || keyList['P']) {
    takeMazeShot();
  }
  
  // Cheat to change light levels
  if (debugMode && keyList['=']) {
    player.glow += 1;
  }
  if (debugMode && keyList['-']) {
    player.glow = max(player.glow - 1, player.glowInit);
  }
  
  if (keyList[']'] && !keyPressedList[']']) {
    debugMode = !debugMode;  
    keyPressedList[']'] = true;
  }
  
  
}

////////////////////////////////////////////////////////////////////////////////////////////
public void checkMovement()
{
  // Check for movement first. Get WASD input and then normalize to magnitude 1.
 float dx = 0;
 float dy = 0;
 
 if(keyList['a'] || keyList['A']) // move left
  {
    dx -= 1;
  }
  
  if(keyList['w'] || keyList['W']) // move up
  {
    dy -= 1;
  }
  
  if(keyList['d'] || keyList['D']) // move right
  {
    dx += 1;
  }
  
  if(keyList['s'] || keyList['S']) // move down
  {
    dy += 1;
  }
  
  // Divide (dx,dy) by sqrt(2) if both dx, dy, are nonzero.
  // This normalizes the movement vector.
  if(dx != 0 && dy != 0)
  {
    dx *= ISQRT2;
    dy *= ISQRT2;
  }
  
  float moveSpeed = (player.ghost && shiftPressed) ? 5 * player.moveSpeed : player.moveSpeed;
  
  player.move(moveSpeed * dx, moveSpeed * dy);
  
  if (dx != 0 || dy != 0) {
    player.beatSize = min(player.beatSizeMax, player.beatSize + 0.3f * player.dbSize);
    player.beatRate = min(player.beatRateMax, player.beatRate + 0.2f * player.dbRate);
  }
}
//void mouseClicked()
//{
//  int xtm = int((screenX + mouseX) / TILE_SIZE);
//  int ytm = int((screenY + mouseY) / TILE_SIZE);
//  Tile aTile = tiles[xtm][ytm];
//  println(aTile.type);
//  println(aTile.c_bactive);
//  println(aTile.xw);
//  println(aTile.yw);
//  //println(sigmoid(aTile.c_bbase + aTile.c_bactive + aTile.a_b * aTile.alignment));
//}
  public void settings() {  size(1920, 1080, P2D);  smooth(4); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--hide-stop", "maze4" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
